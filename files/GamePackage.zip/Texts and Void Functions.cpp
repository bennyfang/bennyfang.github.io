//Any other void function for story line file for my game

#include <iostream.h>
#include "Header.h"
#include <cstdlib>
#include <ctime>
using namespace std;

status wholestory(status Goku)
{
	status  GokuPiccolo = {"Goku and Piccolo", 6, Goku.maxcombatdamage + 200, Goku.mincombatdamage + 200, Goku.maxchidamage + 200, Goku.minchidamage + 200, Goku.combatdef + 50, Goku.chidef + 50, 
	Goku.maxhp + 2000, Goku.maxhp + 2000, Goku.maxchi + 2000, Goku.maxchi + 2000, cloth[1], hat[1], accesory[0], weapon[0], 11, 500, 0, 0, 3, Goku.item};
	story1();
	Goku = battle(1, Goku, Radditz1);
	while (Goku.winloserun > 0)
	{
	if (Goku.winloserun == 110)
		Goku = battle(1, Goku, Radditz1);
	else if (Goku.winloserun == 111 || Goku.winloserun == 112)
		Goku = wholestory(Goku);
	}
	Goku.winloserun = 3;
	story2();

	GokuPiccolo = battle(1, GokuPiccolo, Radditz2);
	while (GokuPiccolo.winloserun > 0)
	{
		GokuPiccolo.winloserun = 3;
		if (GokuPiccolo.winloserun == 110)
			GokuPiccolo = battle(1, GokuPiccolo, Radditz2);
		else if (GokuPiccolo.winloserun == 111)
		{
			story2();
			GokuPiccolo = battle(1, GokuPiccolo, Radditz2);
		}
		else if (GokuPiccolo.winloserun == 112)
			Goku = wholestory(Goku);
	}
	cout << "Piccolo has left the party.(Your stats returned to normal)\nPress enter to countinue.\n";
	cinspace();
	Goku = levelup(Goku);
	Goku.experience = Goku.experience - 550;
	Goku.money = Goku.money + 500;
	Goku.skill = 1;
	story3();
	story4();
	Goku = menu2(Goku);
	Goku = onthepath(Goku);
	story5();
	Goku = training(Goku);
	Goku = menu3(Goku);
	Goku = pathagain(Goku);
	Goku = lastrest(Goku);
	story6();
	Goku = finalboss(Goku);
	return Goku;
}

void display(status user)
{
	float expneeded[50];
	expneeded[5] = 0;
	expneeded[6] = 50;
	for (int i = 7; i < 50; i++)
		expneeded[i] = (expneeded[i-1] * 2);
	cout << user.name << "			Level " <<user.level << "\n"
			"HP:			" << user.currenthp << "/" << user.maxhp << "\n"
			"CHI:			" << user.currentchi << "/" << user.maxchi << "\n"
			"EXP:			" << user.experience << "/" << 500 + expneeded[user.level] << "\n"
			"COMBAT ATTACK:		" << user.mincombatdamage << " - " << user.maxcombatdamage << "\n"
			"CHI ATTACK:		" << user.minchidamage << " - " << user.maxchidamage << "\n"
			"COMBAT DEF:		" << user.combatdef << "\n"
			"CHI DEF:		" << user.chidef << "\n\n\n"
			"Press enter to see more...\n";
	cinget();
	cout << "CLOTH EQUIPPED:		" << user.ecloth.ename << "\n"
			"CLOTH STATS:\n"
			"		COMBAT ATTACK + " << user.ecloth.ecombatdamage << "\n"
			"		CHI ATTACK + " << user.ecloth.echidamage << "\n"
			"		COMBAT DEF + " << user.ecloth.ecombatdef << "\n"
			"		CHI DEF+ " << user.ecloth.echidef << "\n\n\n"
			"HAT EQUIPPED:		" << user.ehat.ename << "\n"
			"HAT STATS:\n"
			"		COMBAT ATTACK + " << user.ehat.ecombatdamage << "\n"
			"		CHI ATTACK + " << user.ehat.echidamage << "\n"
			"		COMBAT DEF + " << user.ehat.ecombatdef << "\n"
			"		CHI DEF + " << user.ehat.echidef << "\n\n\n"
			"ACCESORY EQUIPPED:	" << user.eaccesory.ename << "\n"
			"ACCESORY STATS:\n"
			"		COMBAT ATTACK + " << user.eaccesory.ecombatdamage << "\n"
			"		CHI ATTACK + " << user.eaccesory.echidamage << "\n"
			"		COMBAT DEF + " << user.eaccesory.ecombatdef << "\n"
			"		CHI DEF + " << user.eaccesory.echidef << "\n\n\n"
			"WEAPON EQUIPPED:	" << user.eweapon.ename << "\n"
			"WEAPON STATS:\n"
			"		COMBAT ATTACK+ " << user.eweapon.ecombatdamage << "\n"
			"		CHI ATTACK+ " << user.eweapon.echidamage << "\n"
			"		COMBAT DEF+ " << user.eweapon.ecombatdef << "\n"
			"		CHI DEF+ " << user.eweapon.echidef << "\n\n\n"
			"Reminder: Your total stat is your character status + equipment status\n\n\n"
			"Press enter to continue\n";
			cinget();
			space();
}

void skilldisplay(int s)
{
	if (s == 0)
		cout << "You have mastered no skill currently. Please try again later in the story =(\n\n\n";
	else if (s == 1)
	{
		cout << "Your current skill is/are:\n\n\n"
				"Kamehameha[Chi technique]: This is the most famous, widely-used attack on Dragon Ball.\n"
				"The Kamehameha is a powerful battering ram of continuous energy, which can be diverted\n"
				"by the fighter's arm gestures of placing his hands together at the wrists and chanting the syllables. \n\n"
				"Damage equals to base chi attack + 300DMG. Consumes 1500 chi\n";
	}
	
	else if (s == 11)
	{
		cout << "Your current skill is/are:\n\n\n"
				"Kamehameha[Chi technique]: This is the most famous, widely-used attack on Dragon Ball.\n"
				"The Kamehameha is a powerful battering ram of continuous energy, which can be diverted\n"
				"by the fighter's arm gestures of placing his hands together at the wrists and chanting the syllables. \n\n"
				"Damage equals to base chi attack + 300DMG. Consumes 1500 chi\n\n\n"
				"Makankosappo[Chi technique]: Piccolo's signature attack.\n"
				"The Special Beam cannon is generated when Piccolo touches his fore\n"
				"and middle finger to his forehead, points outward and creates a spiraling beam of yellow energy\n"
				"that makes the entire attack look something like a drill.\n\n"
				"Damage equals to 150% chi attack + 10% combat attack. Consumes 2500 chi\n";
	}
	else if (s == 110)
	{
		cout << "Your current skill is/are:\n\n\n"
				"Kamehameha[Chi technique]: This is the most famous, widely-used attack on Dragon Ball.\n"
				"The Kamehameha is a powerful battering ram of continuous energy, which can be diverted\n"
				"by the fighter's arm gestures of placing his hands together at the wrists and chanting the syllables. \n\n"
				"Damage equals to base chi attack + 300DMG. Consumes 1500 chi\n\n\n";
				"Kaioken[Combat technique]: This is a power up technique that allows the user\n"
				"to amplify energy up to much as the user likes\n"
				"Damage equals to 150% combat attack + 500 DMG. Consumes 2500 chi\n";
	}
	
	else if (s == 101)
	{
		cout << "Your current skill is/are:\n\n\n"
				"Kamehameha[Chi technique]: This is the most famous, widely-used attack on Dragon Ball.\n"
				"The Kamehameha is a powerful battering ram of continuous energy, which can be diverted\n"
				"by the fighter's arm gestures of placing his hands together at the wrists and chanting the syllables.\n\n"
				"Damage equals to base chi attack + 300DMG. Consumes 1500 chi\n\n\n"
				"Kaioken[Combat technique]: This is a powerful technique that allows\n"
				"the user to borrow energy from all the things around him\n."
				"Damage equals to 150% chi attack + 1000 DMG. Consumes 2500 chi\n";
	}
	cout << "Press enter to continue\n";
	cinspace();
}

void space()
{
	cout << "\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
}

void wait(int delay)
{
	clock_t wait = delay * CLOCKS_PER_SEC;
	clock_t start = clock();
	while (clock() - start < wait)
		;
}

void cinget()
{
	cin.get();
	cin.ignore();
}

void cinspace()
{
	cinget();
	space();
}

void bossbattle(char a[strsize], char b[strsize])
{
	space();
	cout << ":::====  :::====  :::===  :::===	\n"
			":::  === :::  === :::     :::		\n"    
			"=======  ===  ===  =====   =====	\n" 
			"===  === ===  ===     ===     ===	\n"
			"=======   ======  ======  ======	\n\n"                           
			":::====  :::====  :::==== :::==== :::      :::=====	\n"
			":::  === :::  === :::==== :::==== :::      :::     	\n"
			"=======  ========   ===     ===   ===      ======  	\n"
			"===  === ===  ===   ===     ===   ===      ===     	\n"
			"=======  ===  ===   ===     ===   ======== ========	\n\n\n"
			<< a << " VS " << b << "\n";
			wait(2);
			space();
}

void plainenemybattle()
{
	space();
	cout << ":::====  :::      :::====  ::: :::= ===				\n"
			":::  === :::      :::  === ::: :::=====				\n"
			"=======  ===      ======== === ========				\n"
			"===      ===      ===  === === === ====				\n"
			"===      ======== ===  === === ===  ===                \n"                       
			":::===== :::= === :::===== :::=======  ::: ===			\n"
			":::      :::===== :::      ::: === === ::: ===			\n"
			"======   ======== ======   === === ===  ===== 			\n"
			"===      === ==== ===      ===     ===   ===  			\n"
			"======== ===  === ======== ===     ===   ===           \n"                       
			":::====  :::====  :::==== :::==== :::      :::=====	\n"
			":::  === :::  === :::==== :::==== :::      :::     	\n"
			"=======  ========   ===     ===   ===      ======  	\n"
			"===  === ===  ===   ===     ===   ===      ===     	\n"
			"=======  ===  ===   ===     ===   ======== ========	\n\n\n"
			"It would be a shame if you lost to him/her/it!!! xD\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
			wait(2);
			space();
}

void ASCIItitle()
{
	cout << "Press enter to continue and press alt+enter to make the game full screen.\n";
	cinspace();
	cout <<"Dragon Ball Z-Vegeta's Ambition	\n\n\n\n\nA Benny Fang Game =)\n"
			"Loading...\n";
	wait(3);
	cout << "Loading complete.\n\n\n\n\n\n\n\n\n\n\n"
			"Press enter to start\n";
	cinspace();
}

void story1()
{
	cout << "Years has passed since Goku defeated Piccolo...\n";
	wait(2);
	cout << "Goku married Chi Chi and had a son named Gohan. They lived in peace until this particular day\n"
			"when Goku goes off with Gohan, who is only 5 years old, to visit Master Roshi and Krillin.\n\n\n\n\n";
	cout << "Goku: Long time no see, Master Roshi.";
	cinget();
	cout << "Krillin: Hey, Goku! Long time no see.";
	cinget();
	cout << "Master Roshi: Ah, Goku. You have grown even bigger since the last time I saw you.";
	cinget();
	cout << "Master Roshi: Who is this little fellow here..Don't tell me that's...";
	cinget();
	cout << "Goku: Yea, he is my son, Gohan. Say hello to everyone, Gohan.";
	cinget();
	cout << "Gohan: Hello. Weeeeeeeeeeee.(Runs Around)";
	cinget();
	cout << "Krillin: He is so cute! I wish I have a wife..";
	cinget();
	cout << "Master Roshi: OMG! So your wife is Chi Chi?";
	cinget();
	cout << "Goku: Yea, but she is very aggressive though, not letting me training Gohan.\n"
			"Don't tell her I said this. - -|";
	cinget();
	cout << "Krillin: (smirks) Good thing I don't have a wife like...";
	cinget();
	cout << "Krillin: What's THAT?!";
	cinget();
	cout << "Goku: I sense a high level chi too.";
	cinget();
	cout << "Master Roshi: Whaaa?";
	cinget();
	cout << "Goku: Here it comes!";
	cinget();
	cout << "Suddenly, a guy with a monkey tail and a earphone on his head flies over and land on the Roshi house.\n\n\n\n\n"
			"Goku: Who are you?";
	cinget();
	cout << "The Man: My name is Radditz, a Saiyan.";
	cinget();
	cout << "Goku notices that the man's monkey tail is identical to the one he had when he was small.\n\n\n\n\n"
			"Radditz: Your real name is Kakarot, your mission was suppose be destroying Earth. Why is this planet still well?";
	cinget();
	cout << "Goku: What? I don't even know you.";
	cinget();
	cout << "Radditz: Have you lost your mind, Kakarot? I am your brother, Radditz! You are one of the only four surviving Saiyans.";
	cinget();
	cout << "Goku: No, I don't even know what Saiyans are. I am human!";
	cinget();
	cout << "Master Roshi: Perhaps I can explain this. Goku hit his head when he was small and lost his past memories, so he didn't remember.";
	cinget();
	cout << "Radditz: So, now you don't remember and you have aligned with the humans, Kakarot? And who is this boy? Your son?";
	cinget();
	cout << "Goku: Yes, and what do you want?";
	cinget();
	cout << "Radditz: Hehe, nothing. Just to take him from you and train him into a real Saiyan.";
	cinget();
	cout << "Goku: No, I wouldn't let you take him, leave him alone.";
	cinget();
	cout << "Radditz: I would like to see you try. After all, you still have your Saiyan power.";
	cinget();
	cout <<	"Radditz charges and starts to fight Goku.\n\n\n\n\n";
	cout << "Finally, it is your turn to experience this game! You can select commands to choose what you can do in a battle every turn\n"
			"When you successfully reduce the enemy's hp to 0, you win, but if your hp reach 0, you lose.\n"
			"Chi is like mana points because you need them to perform your skills.\n"
			"Right now, you can enjoy your first battle and try to defeat Radditz. You can learn more about battle this way, too.\n\n\n"
			"Press enter to continue\n\n\n\n\n";
	cinget();
}

void story2()
{
	cout << "Goku: This is over. I win.\n"
			"Goku: ...";
	cinget();
	cout << "Goku: Impossible...You still have a lot of energy left!";
	cinget();
	cout << "Radditz: Don't you know? I was only testing you. Muhahahaha.\n\n\n"
			"Radditz knocks Master Roshi and Krillin down, then he grabs Gohan before Goku turns around.";
	cinget();
	cout << "Goku: Damn...Put my son down, you monster!";
	cinget();
	cout << "Radditz: Only if you have the skill. I don't need you now, only your son, Kakarot!\n\n\n"
			"Radditz uses his real power and knocks Goku down in few strikes. Then he flies away.";
	cinget();
	cout << "Goku: I am too weak...I let him took my son.";
	cinget();
	cout << "???: Hmph, is this really the Goku I knew?";
	cinget();
	cout << "Goku: Piccolo! What are you up to?";
	cinget();
	cout << "Piccolo: Nothing. Just come to see an old rival and the new opponent.";
	cinget();
	cout << "Piccolo: Although I don't want to, we have to become temporary allies to save your son and beat that Saiyan.";
	cinget();
	cout << "Goku: You are right. We need to work together...Hey, how'd you know about Saiyans.";
	cinget();
	cout << "Piccolo: Hehe, don't you understand? I have a special pair of ears. Anyways, lets go following that Radditz's Chi.\n\n\n"
			"Goku and Piccolo take off and soon find Radditz and his spaceship with Gohan trapped inside. They land.\n\n\n";
	cinget();
	cout << "Radditz: Humph, I see you brought another of your weak companians.";
	cinget();
	cout << "Piccolo: We'll see about that, don't we? You are just underestimating us. Goku, show him our real powers.";
	cinget();
	cout << "Both Goku and Piccolo releases chi and the real battle begins.\n"
			"Please note that your power is temporarily enhanced by Piccolo's power and Radditz's power has gone up too.";
	cinget();
	cout <<	"Congradulation. Now Goku releases his power to use Kamehameha, the energy beam and Piccolo releases his power to use Makankosappo, the beam cannon.\n"
			"A reminder: in battle you recover 10% chi in battle as long as your current chi is not bigger than your max chi =).\n"
			"Press enter to continue.";
	cinspace();
}

void story3()
{
	cout << "Radditz: Hehehe. You guys are better than I expected, but not good enough.\n"
			"Radditz: Now, I will...\n\n\n";
	cinget();
	cout << "Goku already sneaked behind Radditz and grabbed him the behind, Radditz is unable to move.";
	cinget();
	cout << "Radditz: You sneak! How dare you touch me?!";
	cinget();
	cout << "Goku: Now, Piccolo!";
	cinget();
	cout << "Piccolo: Makankosappo!!!";
	cinget();
	cout << "The energy beam gos straight through Radditz and Goku.";
	cinget();
	cout << "Piccolo: Goku, Goku!\n"
			"Piccolo: You did well. May you rest in peace.";
	cinget();
	cout << "Radditz: Re..Rest in peace? Impossible! One year later and the other two Saiyans will come!\n"
			"Radditz: You can watch your beloved planet burn down to pieces, Kakarot! Hahahahaha!";
	cinget();
	cout << "Piccolo: Damn you...But we have dragon balls. Seven of them and we can grant any wish we want.\n"
			"Piccolo: And then we can revive Goku and he will kill the two Saiyans you are talking about.";
	cinget();
	cout << "Radditz: Did you hear that, guys? There are these magical item called the dragon balls\n"
			"A volce comes out of the earphone: Yes I did, Radditz. Once I get the dragon balls I will become invincible.";
	cinget();
	cout << "Piccolo: What?! Those earphones are transmitters?\n"
			"Piccolo steps on the earphones, but he realizes that it is too late.";
	cinget();
	cout << "Both Radditz and Goku are dead now. And Goku is teleported to the underworld.\n"
			"Piccolo breaks the ship and rescues Gohan.\n"
			"Piccolo: I will take care of your son, Goku. I promise.\n"
			"Press enter to continue\n";
	cinspace();
}

void story4()
{
	cout << "Meanwhile, Here is Goku in the underworld. He waits in the lineup until\nhe sees King Yemma, the king of the underworld\n";
	cinget();
	cout << "Goku: Hey, Mr.Underworld King. Do you know where I could go to train myself?";
	cinget();
	cout << "King Yemma: Huh, who is this that dares to disrespect me? I am the great King Yemma, not some Mr.Underworld King.";
	cinget();
	cout << "Goku: Sorry, King Yemma. Do you know...";
	cinget();
	cout << "King Yemma: Hahaha, so you are Goku. I heard all about everything you did while you were alive.\n"
			"King Yemma: I know you are possessed with training, but what does a dead person need of training anyways?";
	cinget();
	cout << "Goku: Yea, maybe you are right, but I can't let the Saiyans that will come to Earth in one year to destroy Earth.";
	cinget();
	cout << "King Yemma: Very well, I guess you'll be using the dragon balls?\n"
			"King Yemma: I'll grant your wish. Just go the door to the right and you will find a path that is 108 thousand km long.\n";
	cinget();
	cout <<	"King Yemma: If you are worthy, you can reach the end of the pass and find the great mentor of fighters---King Kai!\n"
			"King Yemma: One last thing, if you prove to me first that you are worthy by training to level 9 through the left door, I will give you something in return. Good luck.";
	cinget();
	cout << "Goku: Ok. I will.\n\n\n";
	cinget();
	cout << "Now you are in free choice mode. As long as you don't choose to continue the story, you can keep training in here.\n"
			"You can choose to train(left door), continue the story(right door), rest(recover hp and mp) and shop(buy stuff).\n"
			"And one more thing, you can only BUY items in the shop. There are two types of items: potions and equipments,\nwhich one is used for healing and the other for enhancing ability.\n"
			"Press enter to continue.\n";
	cinspace();
}

status menu2(status u)
{
	srand(time(0));
	short choice;
	short story = 0;
	short randommonster;
	
	while (story == 0)
	{
		if (u.level == 9)
		{
			cout << "King Yemma: You have proven to me that you are worthy now.\n"
					"You received an underworld sword.\n"
					"You received 1000 Z Coin and 900 experience.\n"
					"You received 3 small hp potion and 3 small chi potion.\n"
					"Press enter to countinue\n";
			cinspace();
			u.money = u.money + 1000;
			u.experience = u.experience + 900;
			u = levelup(u);
			u.experience = u.experience - 900;
			u.item.smallhppotion = u.item.smallhppotion + 3;
			u.item.smallchipotion = u.item.smallchipotion + 3;
			u.item.iweapon = weapon[2];
		}
		cout << "What do you want to do now?\n\n\n"
				"1) Go through the left door to train\n"
				"2) Go through the right door to the path\n"
				"3) Rest in the King's palace(free xD)				4) Shop\n"
				"5) See my status	6) Sort my equipment and see my items\n";
		cin >> choice;
		switch(choice)
		{
			case 1: 
				randommonster = rand() % 2 + 1;
				if (randommonster == 1)
					u = battle(0, u, Ghoul1);
				else if (randommonster == 2)
					u = battle(0, u, Zombie1);
				u.winloserun = 3;
			break;
			
			case 2:
				space();
				story = 1;
			break;
			
			case 3:
				u.currenthp = u.maxhp;
				u.currentchi = u.maxchi;
				cout << "Your hp and chi are restored.\n"
						"Press enter to continue.\n";
				cinspace();
			break;
			
			case 4:
				short shop = 5;
				while (shop != 4)
				{
					cout << "What do you want to buy?\n"
							"1) Small hp potion(restore 20% hp)-500Z\n"
							"2) Small chi potion(restore 50% chi)-400Z\n"
							"3) Bronze sword(+50 cbtatk, +25 chiatk)-1000Z\n"
							"4) Exit shop\n\n\n"
							"You currently have: " << u.money << " Z Coin(s)\n";
					cin >> shop;
					switch(shop)
					{
					case 1:
						if (u.money < 500)
							cout << "You do not have enough Z coins!\n";
						else if (u.money >= 500)
						{
							u.money = u.money - 500;
							u.item.smallhppotion = u.item.smallhppotion + 1;
							cout << "You bought a small hp potion for 500 Z Coins\n."
									"Now you have " << u.item.smallhppotion << " small hp potion(s).\n";
						}
						
						cout << "Press enter to continue\n";
						cinspace();
					break;
					
					case 2:
						if (u.money < 400)
							cout << "You do not have enough Z coins!\n";
						else if (u.money >= 400)
						{
							u.money = u.money - 400;
							u.item.smallchipotion = u.item.smallchipotion + 1;
							cout << "You bought a small chi potion for 500 Z Coins\n."
									"Now you have " << u.item.smallchipotion << " small chi potion(s).\n";
						}
						
						cout << "Press enter to continue\n";
						cinspace();
					break;
					
					case 3:
						char overlap;
						if (u.money < 1000)
							cout << "You do not have enough Z coins!\n";
						else if (u.money >= 1000)
						{
							if (u.eweapon.ecombatdamage == 50)
								cout << "You already have bronze sword in your inventory!\n";
							else
							{
								cout << "Do you want to replace your current weapon '" << u.item.iweapon.ename << "'?<y/n>\n";
								cin >> overlap;
									if (overlap == 'y' || overlap == 'Y')
									{
										u.item.iweapon = weapon[1];
										u.money = u.money - 1000;
										cout << "You have bought bronze sword for 1000 Z Coins!\n";
									}
									
									else
										cout << "Transaction has been cancelled.\n";
							}
						}
						cout << "Press enter to continue\n";
						cinspace();
					break;
					
					case 4:
						space();
					break;
					
					default: 
						cout << "That is not a choice! Please try again.\n"
								"Press enter to continue\n";
						cinspace();
					}
				}
				
			break;
			
			case 5:
			
			short check = 4;
				while (check != 3)
				{
				cout << "Please select the stat you want to see\n\n\n"
						"1) See character stat point and equip\n"
						"2) See character skill\n"
						"3) Go back to battle menu\n";
				cin >> check;
						if (check == 1)
							display(u);		
						else if (check == 2)
							skilldisplay(u.skill);	
						else if (check == 3)
						 	space();
						else
						{
							cout << "That is not a choice!\n"
									"Press enter to continue\n";
							cinspace();
						}
				}
			break;
			
			case 6:
				short changeequip;
				equipstatus change;
				cout << "Here are all your items:\n\n\n"
						"Cloth in inventory: 		" << u.item.icloth.ename << "\n"
						"Cloth currently equipped:	" << u.ecloth.ename << "\n"
						"Hat in inventory: 		" << u.item.ihat.ename << "\n"
						"Hat currently equipped:		" << u.ehat.ename << "\n"
						"Accesory in inventory: 		" << u.item.iaccesory.ename << "\n"
						"Accesory currently equipped:	" << u.eaccesory.ename << "\n"
						"Weapon in inventory: 		" << u.item.iweapon.ename << "\n"
						"Weapon currently equipped:	" << u.eweapon.ename << "\n"
						"Number of small hp potion(s):	" << u.item.smallhppotion << "-This stores 20% of your maximum hp\n"
						"Number of large hp potion(s): 	" << u.item.largehppotion << "-This stores 40% of your maximum hp\n"
						"Number of small chi potion(s):  " << u.item.smallchipotion << "-This stores 25% of your maximum chi\n"
						"Number of small hp potion(s): 	" << u.item.largechipotion << "-This stores 50% of your maximum chi\n"
						"Number of magical bean(s): 	" << u.item.magicalbean << "-This stores all hp and chi\n"
						"Your Z Coins: " << u.money << "\n"
						"Note that you can only use potions in battle!\n\n\n"
						"What do you want to do?\n"
						"1)Change cloth			2)Change hat\n"
						"3)Change accesory		4)Change weapon\n"
						"5)Exit\n";
				cin >> changeequip;
				
				switch(changeequip)
				{
					case 1:
						cout << "You changed from " << u.ecloth.ename << " to " << u.item.icloth.ename << "\n";
						change = u.ecloth;
						u.ecloth = u.item.icloth;
						u.item.icloth = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
					
					case 2:
						cout << "You changed from " << u.ehat.ename << " to " << u.item.icloth.ename << "\n";
						change = u.ehat;
						u.ehat = u.item.ihat;
						u.item.ihat = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
					
					case 3:
						cout << "You changed from " << u.eaccesory.ename << " to " << u.item.iaccesory.ename << "\n";
						change = u.eaccesory;
						u.eaccesory = u.item.iaccesory;
						u.item.iaccesory = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
					
					case 4:
						cout << "You changed from " << u.eweapon.ename << " to " << u.item.iweapon.ename << "\n";
						change = u.eweapon;
						u.eweapon = u.item.iweapon;
						u.item.iweapon = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
					
					case 5:
						space();
					break;
					
					default: 
						cout << "That is not a choice!\n"
								"Press enter to continue\n";
						cinspace();
				}
			break;
			
			default:
				cout << "That is not a choice.\n"
						"Press enter to continue.\n";
				cinspace();
		}
	}
	return u;
}

status onthepath(status u)
{
	short path;
	cout << "You challenged the path...\n\n\n";
	wait(2);
	cout << "On the way to the path you see a Ghoul.\n"
			"For passing the path, you must defeat the ghoul.\n"
			"Press enter to continue\n";
	cinspace();
	u = battle(1, u, Ghoul2);
	while (u.winloserun > 0)
	{
		if (u.winloserun == 110)
		{
			u.winloserun = 3;
			u = battle(1, u, Ghoul2);
		}
		else if (u.winloserun == 111)
		{
			u.winloserun = 3;
			u = menu2(u);
			u = battle(1, u, Ghoul2);
		}
		else if (u.winloserun == 112)
			u = wholestory(u);
	}
	
	u.winloserun = 3;
	cout << "There are more!\n"
			"Press enter to continue\n";
	cinspace();
	
	u = battle(1, u, Zombie2);
	while (u.winloserun > 0)
	{
		if (u.winloserun == 110)
		{
			u.winloserun = 3;
			u = battle(1, u, Zombie2);
		}
		else if (u.winloserun == 111)
		{
			u.winloserun = 3;
			u = menu2(u);
			u = battle(1, u, Ghoul2);
			u.winloserun = 3;
			u= battle(1, u, Zombie2);
		}
		else if (u.winloserun == 112)
			u = wholestory(u);
	}
	
	u.winloserun = 3;
	cout << "You have reached a three way split!\n"
			"Which way do you want to go?\n"
			"1) Left		2) Middle	3) Right\n";
	cin >> path;
	switch(path)
	{
		case 1:
			cout << "You choose left. Now a red ghost blocks your way!\n"
					"You have to fight him now.\n"
					"Press enter to continue.\n";
			cinspace();
			u = battle(1, u, RedGhost);
			while (u.winloserun > 0)
			{
				if (u.winloserun == 110)
				{
					u.winloserun = 3;
					u = battle(1, u, RedGhost);
				}
				else if (u.winloserun == 111)
				{
					u.winloserun = 3;
					u = menu2(u);
					u = battle(1, u, Ghoul2);
					u.winloserun = 3;
					u = battle(1, u, Zombie2);
					u.winloserun = 3;
					u = battle(1, u, RedGhost);
				}
				else if (u.winloserun == 112)
					u = wholestory(u);
			}
			u.eaccesory = accesory[1];
			cout << "You get an underworld neckless\n"
					"You equipped it.\n"
					"Press enter to continue\n";
					
		break;
		
		case 2:
			cout << "You choose middle. Now a snake girl blocks your way!\n"
					"You have to fight her now.\n"
					"Press enter to continue.\n";
			cinspace();
			u = battle(1, u, SnakeGirl);
			while (u.winloserun > 0)
			{
				if (u.winloserun == 110)
				{
					u.winloserun = 3;
					u = battle(1, u, SnakeGirl);
				}
				else if (u.winloserun == 111)
				{
					u.winloserun = 3;
					u = menu2(u);
					u = battle(1, u, Ghoul2);
					u.winloserun = 3;
					u = battle(1, u, Zombie2);
					u.winloserun = 3;
					u = battle(1, u, SnakeGirl);
				}
				else if (u.winloserun == 112)
					u = wholestory(u);
			}
			u.ecloth = cloth[2];
			cout << "You get an underworld cloth\n"
					"You equipped it.\n"
					"Press enter to continue\n";
		break;
					
		case 3:
			cout << "You choose right. Now a blue ghost blocks your way!\n"
					"You have to fight her now.\n"
					"Press enter to continue.\n";
			cinspace();
			u = battle(1, u, BlueGhost);
			while (u.winloserun > 0)
			{
				if (u.winloserun == 110)
				{
					u.winloserun = 3;
					u = battle(1, u, BlueGhost);
				}
				else if (u.winloserun == 111)
				{
					u.winloserun = 3;
					u = menu2(u);
					u = battle(1, u, Ghoul2);
					u.winloserun = 3;
					u = battle(1, u, Zombie2);
					u.winloserun = 3;
					u = battle(1, u, BlueGhost);
				}
				else if (u.winloserun == 112)
					u = wholestory(u);
			}
			u.ehat = hat[2];
			cout << "You get an underworld hat\n"
					"You equipped it.\n"
					"Press enter to continue\n";
		break;
		
		
		default:
			cout << "That is not a choice!\n"
					"Press enter to continue.\n";
			cinspace();
	}
	
	u.winloserun = 3;
	cout << "You successfully passed the path!\n"
			"Press enter to continue.\n";
	cinspace();
			
	return u;
}

void story5()
{
	cout << "Goku: I'm finally here! Where is...Aaaaaaa!\n"
			"Goku: Why did my body became heavy all the sudden. I can't get up!";
	cinget();
	cout << "???: Ofcourse! You are not adapted to the gravity here yet.";
	cinget();
	cout << "Goku: Hey.. Are you King Kai?";
	cinget();
	cout << "King Kai: Yes, I'm King Kai. I understand everything about you, Goku.";
	cinget();
	cout << "Goku: Cool, then I guess I won't have to explain, do I?";
	cinget();
	cout << "King Kai: Yes, but I do have to tell you something: The Saiyans you will face are 5 times stronger than Radditz.";
	cinget();
	cout << "Goku: =O I get it. Let's just start our training, shall we?";
	cinget();
	cout << "King Kai: Geez, you are in such a rush.";
	cinget();
	cout << "Goku: We don't much time! They are here in one year.";
	cinget();
	cout << "King Kai: Ok, ok, let's start. First, you must defeat my little pet gorilla here.";
	cinget();
	cout << "Goku: This gorilla thing? Easy!";
	cinget();
	cout << "King Kai: Hahaha, don't underestimate him. He already adapted to the gravity here, so he is ten times stronger than he looks.";
	cinget();
	cout << "Gorilla: Huhuhu!\n"
			"The battle begins.\n"
			"Press enter to start\n";
	cinspace();
}

status training(status u)
{
	short choosejob = 3;
	u = battle(1, u, Gorilla);
	while (u.winloserun > 0)
	{
		if (u.winloserun == 110)
		{
			u.winloserun = 3;
			u = battle(1, u, Gorilla);
		}
		else if (u.winloserun == 111)
		{
			u.winloserun = 3;
			story5();
			u = battle(1, u, Gorilla);
		}
		else if (u.winloserun == 112)
			u = wholestory(u);
	}
	u.winloserun = 3;
	cout << "King Kai: Not bad, next up is my pet bee.";
	cinget();
	cout << "Goku: Ok...I guess it's not weak as well.";
	cinget();
	cout << "Press enter to continue\n";
	cinspace();
	u = battle(1, u, Bee);
	while (u.winloserun > 0)
	{
		if (u.winloserun == 110)
		{
			u.winloserun = 3;
			u = battle(1, u, Bee);
		}
		else if (u.winloserun == 111)
		{
			u.winloserun = 3;
			story5();
			u = battle(1, u, Gorilla);
			u.winloserun = 3;
			u = battle(1, u, Bee);
		}
		else if (u.winloserun == 112)
			u = wholestory(u);
	}
	u.winloserun = 3;
	cout << "King Kai: Good. Now we can start our training formally.\n"
			"Press enter to continue\n";
	cinspace();
	cout << "9 month has passed\n"
			"You have became way stronger...\n\n\n";
	wait(2);
	cout << "King Kai: Goku, now it's your turn to decide which job you want to be\n";
	cinget();
	cout << "Goku: Job?";
	cinget();
	cout << "King Kai: Yes, you can become a combat master or chi master, one depends on close combat attack\n"
			"King kai: And one depends on the use of chi\n";
	cinget();
	cout << "King Kai: This is an important choice because once you choose your job you may never change it.";
	cinget();
	while (choosejob > 2)
	{
		cout << "King Kai: What do you want to be?\n"
				"1)Combat Master		2)Chi Master\n";
		cin >> choosejob;
		if (choosejob == 1)
		{
			cout << "King Kai: Congradulation, now you are a combat master!\n"
					"You learned Kaoiken, a power up technique that allows the user\n"
					"to amplify energy by how ever much they desire.\n";
			u.job = 1;
			u = changejob(u);
		}
		
		else if (choosejob == 2)
		{
			cout << "King Kai: Congradulation, now you are a chi master!\n"
					"You learned spirit bomb, a powerful technique that allows\n"
					"the user to borrow energy from all the things around him.\n"
					"Note that from now on you need to consume 2 times the chi than before\n";
			u.job = 2;
			u = changejob(u);
		}
		
		else
			cout << "That is not a choice!\n";
		cout << "Press enter to continue\n";
		cinspace();
	}
	
	u = levelup(u);
	u = levelup(u);
	u = levelup(u);
	u = levelup(u);
	u = levelup(u);
	cout << "King Kai: Now you only need more training by yourself to do.\n"
			"King Kai: If you think you are ready to handle the Saiyans, go back from the path you cam from\n"
			"King Kai: And your friends on Earth will use the DBs to revive you and get you back on Earth.\n";
	cinspace();
	return u;
}

status menu3(status u)
{
	srand(time(0));
	short choice;
	short story = 0;
	short randommonster;
	
	while (story == 0)
	{
		if (u.level == 15)
		{
			cout << "King Kai: You have proven to me that you are worthy now.\n"
					"You received an King Kai Suit.\n"
					"You received 10000 Z Coin and .\n"
					"You received 5 large hp potion and 5 large chi potion.\n"
					"Press enter to countinue\n";
			cinspace();
			u.money = u.money + 10000;
			u = levelup(u);
			u.item.largehppotion = u.item.largehppotion + 5;
			u.item.largechipotion = u.item.largechipotion + 5;
			u.item.icloth = cloth[3];
		}
		cout << "What do you want to do now?\n\n\n"
				"1) Go train even more\n"
				"2) Go to Earth from the path again\n"
				"3) Rest in King Kai's palace(not free anymore-500 a time)\n4) Shop		"
				"5) See my status	6) Sort my equipment and see my items\n";
		cin >> choice;
		switch(choice)
		{
			case 1: 
				randommonster = rand() % 2 + 1;
				if (randommonster == 1)
					u = battle(0, u, WildGorilla);
				else if (randommonster == 2)
					u = battle(0, u, WildBee);
				u.winloserun = 3;
			break;
			
			case 2:
				space();
				story = 1;
			break;
			
			case 3:
			if (u.money >= 500)
			{
				u.currenthp = u.maxhp;
				u.currentchi = u.maxchi;
				u.money = u.money - 500;
				cout << "Your hp and chi are restored.\n"
						"You paid 500 Z Coins\n"
						"Press enter to continue.\n";
			}
			
			else
				cout << "You do not have enough money!\n"
						"Press enter to continue\n";
			cinspace();
			break;
			
			case 4:
				short shop = 6;
				while (shop != 5)
				{
					cout << "What do you want to buy?\n"
							"1) Large hp potion(restore 20% hp)-2000Z\n"
							"2) Large chi potion(restore 50% chi)-1800Z\n"
							"3) Kai sword(+400 cbtatk, +300 chiatk)-5000Z\n"
							"4) Kai Neckless(+100 cbtatk, +100 chiatk, +25 cbtdef, +25chidef)-4500Z\n"
							"5) Exit shop\n\n\n"
							"You currently have: " << u.money << " Z Coin(s)\n";
					cin >> shop;
					switch(shop)
					{
					case 1:
						if (u.money < 2000)
							cout << "You do not have enough Z coins!\n";
						else if (u.money >= 2000)
						{
							u.money = u.money - 2000;
							u.item.largehppotion = u.item.largehppotion + 1;
							cout << "You bought a large hp potion for 2000 Z Coins\n."
									"Now you have " << u.item.largehppotion << " large hp potion(s).\n";
						}
						
						cout << "Press enter to continue\n";
						cinspace();
					break;
					
					case 2:
						if (u.money < 1800)
							cout << "You do not have enough Z coins!\n";
						else if (u.money >= 1800)
						{
							u.money = u.money - 1800;
							u.item.largechipotion = u.item.largechipotion + 1;
							cout << "You bought a large chi potion for 1800 Z Coins\n."
									"Now you have " << u.item.largechipotion << " large chi potion(s).\n";
						}
						
						cout << "Press enter to continue\n";
						cinspace();
					break;
					
					case 3:
						char overlap1;
						if (u.money < 5000)
							cout << "You do not have enough Z coins!\n";
						else if (u.money >= 5000)
						{
							if (u.eweapon.ecombatdamage == 400)
								cout << "You already have Kai sword in your inventory!\n";
							else
							{
								cout << "Do you want to replace your current weapon '" << u.item.iweapon.ename << "'?<y/n>\n";
								cin >> overlap1;
									if (overlap1 == 'y' || overlap1 == 'Y')
									{
										u.item.iweapon = weapon[3];
										u.money = u.money - 5000;
										cout << "You have bought Kai sword for 5000 Z Coins!\n";
									}
									
									else
										cout << "Transaction has been cancelled.\n";
							}
						}
						cout << "Press enter to continue\n";
						cinspace();
					break;
					
					case 4:
						char overlap2;
						if (u.money < 4500)
							cout << "You do not have enough Z coins!\n";
						else if (u.money >= 4500)
						{
							if (u.eaccesory.ecombatdamage == 100)
								cout << "You already have Kai neckless in your inventory!\n";
							else
							{
								cout << "Do you want to replace your current accesory '" << u.item.iaccesory.ename << "'?<y/n>\n";
								cin >> overlap2;
									if (overlap2 == 'y' || overlap2 == 'Y')
									{
										u.item.iaccesory = accesory[2];
										u.money = u.money - 4500;
										cout << "You have bought Kai neckless for 4500 Z Coins!\n";
									}
									
									else
										cout << "Transaction has been cancelled.\n";
							}
						}
						cout << "Press enter to continue\n";
						cinspace();
					break;
					
					case 5:
						space();
					break;
					
					default: 
						cout << "That is not a choice! Please try again.\n"
								"Press enter to continue\n";
						cinspace();
					}
				}
				
			break;
			
			case 5:
			
			short check = 4;
				while (check != 3)
				{
				cout << "Please select the stat you want to see\n\n\n"
						"1) See character stat point and equip\n"
						"2) See character skill\n"
						"3) Go back to battle menu\n";
				cin >> check;
						if (check == 1)
							display(u);		
						else if (check == 2)
							skilldisplay(u.skill);	
						else if (check == 3)
						 	space();
						else
						{
							cout << "That is not a choice!\n"
									"Press enter to continue\n";
							cinspace();
						}
				}
			break;
			
			case 6:
				short changeequip;
				equipstatus change;
				cout << "Here are all your items:\n\n\n"
						"Cloth in inventory: 		" << u.item.icloth.ename << "\n"
						"Cloth currently equipped:	" << u.ecloth.ename << "\n"
						"Hat in inventory: 		" << u.item.ihat.ename << "\n"
						"Hat currently equipped:		" << u.ehat.ename << "\n"
						"Accesory in inventory: 		" << u.item.iaccesory.ename << "\n"
						"Accesory currently equipped:	" << u.eaccesory.ename << "\n"
						"Weapon in inventory: 		" << u.item.iweapon.ename << "\n"
						"Weapon currently equipped:	" << u.eweapon.ename << "\n"
						"Number of small hp potion(s):	" << u.item.smallhppotion << "-This stores 20% of your maximum hp\n"
						"Number of large hp potion(s): 	" << u.item.largehppotion << "-This stores 40% of your maximum hp\n"
						"Number of small chi potion(s):  " << u.item.smallchipotion << "-This stores 25% of your maximum chi\n"
						"Number of small hp potion(s): 	" << u.item.largechipotion << "-This stores 50% of your maximum chi\n"
						"Number of magical bean(s): 	" << u.item.magicalbean << "-This stores all hp and chi\n"
						"Your Z Coins: " << u.money << "\n"
						"Note that you can only use potions in battle!\n\n\n"
						"What do you want to do?\n"
						"1)Change cloth			2)Change hat\n"
						"3)Change accesory		4)Change weapon\n"
						"5)Exit\n";
				cin >> changeequip;
				
				switch(changeequip)
				{
					case 1:
						cout << "You changed from " << u.ecloth.ename << " to " << u.item.icloth.ename << "\n";
						change = u.ecloth;
						u.ecloth = u.item.icloth;
						u.item.icloth = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
					
					case 2:
						cout << "You changed from " << u.ehat.ename << " to " << u.item.icloth.ename << "\n";
						change = u.ehat;
						u.ehat = u.item.ihat;
						u.item.ihat = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
					
					case 3:
						cout << "You changed from " << u.eaccesory.ename << " to " << u.item.iaccesory.ename << "\n";
						change = u.eaccesory;
						u.eaccesory = u.item.iaccesory;
						u.item.iaccesory = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
					
					case 4:
						cout << "You changed from " << u.eweapon.ename << " to " << u.item.iweapon.ename << "\n";
						change = u.eweapon;
						u.eweapon = u.item.iweapon;
						u.item.iweapon = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
					
					case 5:
						space();
					break;
					
					default: 
						cout << "That is not a choice!\n"
								"Press enter to continue\n";
						cinspace();
				}
			break;
			
			default:
				cout << "That is not a choice.\n"
						"Press enter to continue.\n";
				cinspace();
		}
	}
	return u;
}

status pathagain(status u)
{
	cout << "Goku: Now I'm fast, I should be able to reach the other end of the path really fast...";
	cinget();
	cout << "Goku: ?!";
	cinget();
	cout << "Blue Ghost, Red Ghost and Snake Girl: You! You are the one who defeated one of us one year ago";
	cinget();
	cout << "Goku: Oh I remember! What do you guys want?";
	cinget();
	cout << "Trio: We want revenge! This time all of us will fight you and kill you";
	cinget();
	cout << "Goku: I don't have time for this...But if you guys really block me, I will finish this fast!\n"
			"Press enter to continue\n";
	cinspace();
	u = battle(1, u, SBL);
	
	while (u.winloserun > 0)
	{
		if (u.winloserun == 110)
		{
			u.winloserun = 3;
			u = battle(1, u, SBL);
		}
		else if (u.winloserun == 111)
		{
			u.winloserun = 3;
			u = menu3(u);
			u = battle(1, u, SBL);
		}
		else if (u.winloserun == 112)
			u = wholestory(u);
	}
	
	u.winloserun = 3;
	u.item.ihat = hat[3];
	cout << "You obtained Kai's Hat!\n"
			"It is now placed in your inventory.\n"
			"Press enter to continu\n";
	cinspace();
	cout << "Goku successfully defeated the trio and reached the end of the path";
	cinget();
	cout << "King Yemma: I've been waiting for you, Goku! Your friends have already revived you.\n"
			"King Yemma: Now hurry! I will teleport you back.";
	cinget();
	cout << "With King Yemma's magic, you were instantly teleported back on Karin's tower(see DB for specific details about it)";
	cinget();
	cout << "Goku: Karin! I need the magical beans!";
	cinget();
	cout << "Karin: Ok! You can get much as you want as long as you have the money!\n"
			"Karin: You can have one free for yourself! I see you are tired running from that path";
	cinget();
	cout << "Your hp and mp are recovered!\n"
			"Here is an advice! Since you are on the save point before the final boss, it is best for you to use up all your money on beans!";
	cinget();
	u.currenthp = u.maxhp;
	u.currentchi = u.maxchi;
	return u;
}

status lastrest(status u)
{
	short choice;
	while (choice != 4)
	{
		cout << "What do you want to do now?\n"
				"1) Buy magical beans! Now on 80% discount! Only 1000 Z Coins EA!\n"
				"2) See my status	3) Sort my equipment and see my items\n"
				"4) Go fight final boss!\n";
		cin >> choice;
		switch(choice)
		{
			case 1:
				if (u.money >= 1000)
				{
					u.item.magicalbean = u.item.magicalbean + 1;
					cout << "You have bought a magical bean!\n"
							"Now you have " << u.item.magicalbean << " magical bean(s)!\n"
							"Press enter to continue\n";
				}
				
				else
					cout << "You do not have enough money\n"
							"Press enter to continue\n";
				cinspace();
			break;

			case 2:
				short check = 4;
				while (check != 3)
				{
					cout << "Please select the stat you want to see\n\n\n"
							"1) See character stat point and equip\n"
							"2) See character skill\n"
							"3) Go back to battle menu\n";
					cin >> check;
							if (check == 1)
								display(u);		
							else if (check == 2)
								skilldisplay(u.skill);	
							else if (check == 3)
							 	space();
							else
							{
								cout << "That is not a choice!\n"
										"Press enter to continue\n";
								cinspace();
							}
				}
			break;
			
			case 3:
				short changeequip;
				equipstatus change;
				cout << "Here are all your items:\n\n\n"
						"Cloth in inventory: 		" << u.item.icloth.ename << "\n"
						"Cloth currently equipped:	" << u.ecloth.ename << "\n"
						"Hat in inventory: 		" << u.item.ihat.ename << "\n"
						"Hat currently equipped:		" << u.ehat.ename << "\n"
						"Accesory in inventory: 		" << u.item.iaccesory.ename << "\n"
						"Accesory currently equipped:	" << u.eaccesory.ename << "\n"
						"Weapon in inventory: 		" << u.item.iweapon.ename << "\n"
						"Weapon currently equipped:	" << u.eweapon.ename << "\n"
						"Number of small hp potion(s):	" << u.item.smallhppotion << "-This stores 20% of your maximum hp\n"
						"Number of large hp potion(s): 	" << u.item.largehppotion << "-This stores 40% of your maximum hp\n"
						"Number of small chi potion(s):  " << u.item.smallchipotion << "-This stores 25% of your maximum chi\n"
						"Number of small hp potion(s): 	" << u.item.largechipotion << "-This stores 50% of your maximum chi\n"
						"Number of magical bean(s): 	" << u.item.magicalbean << "-This stores all hp and chi\n"
						"Your Z Coins: " << u.money << "\n"
						"Note that you can only use potions in battle!\n\n\n"
						"What do you want to do?\n"
						"1)Change cloth			2)Change hat\n"
						"3)Change accesory		4)Change weapon\n"
						"5)Exit\n";
				cin >> changeequip;
					
				switch(changeequip)
				{
					case 1:
						cout << "You changed from " << u.ecloth.ename << " to " << u.item.icloth.ename << "\n";
						change = u.ecloth;
						u.ecloth = u.item.icloth;
						u.item.icloth = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
						
					case 2:
						cout << "You changed from " << u.ehat.ename << " to " << u.item.icloth.ename << "\n";
						change = u.ehat;
						u.ehat = u.item.ihat;
						u.item.ihat = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
						
					case 3:
						cout << "You changed from " << u.eaccesory.ename << " to " << u.item.iaccesory.ename << "\n";
						change = u.eaccesory;
						u.eaccesory = u.item.iaccesory;
						u.item.iaccesory = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
						
					case 4:
						cout << "You changed from " << u.eweapon.ename << " to " << u.item.iweapon.ename << "\n";
						change = u.eweapon;
						u.eweapon = u.item.iweapon;
						u.item.iweapon = change;
						cout << "Press enter to continue:\n";
						cinspace();
					break;
						
					case 5:
						space();
					break;
						
					default: 
						cout << "That is not a choice!\n"
								"Press enter to continue\n";
						cinspace();
				}
			break;
				
			case 4:
				space();
			break;
			
			default:
				cout << "That is not a choice!\n"
						"Press enter to continue\n";
				cinspace();									
					
		}
	}
	return u;
}
	
void story6()
{
	cout << "Goku uses his full speed to fly to where the Saiyans already landed\n"
			"But when he gets there...";
	cinget();
	cout << "Goku sees many of his companians biting the dust already. They are dead.";
	cinget();
	cout << "Goku: Yamcha, Piccolo, Chiao-tzu, Tenshinhan...";
	cinget();
	cout << "???: Huph, are you Goku?";
	cinget();
	cout << "Goku: Yes, I am. You guys are the Saiyans, right? RIGHT? I won't forgive you!";
	cinget();
	cout << "???: Hahahahahaha, I will tell you our names. I am Nappa, and this one here is my lord Vegeta!";
	cinget();
	cout << "Goku: Which of you wants to die first?";
	cinget();
	cout << "Nappa: I heard you weak companians keep talking about you as their 'hope'!\n"
			"Nappa: There are no more hopes. No more dreams! You will die with them, now let's go!";
	cinget();
	cout << "Goku: I won't lose, because I am the hope!";
	cinget();
	cout << "Battle begins. As you see, your opponent is not the real boss yet! Don't take him very hard.\n"
			"Press enter to continue\n";
	cinspace();
}

status finalboss(status u)
{
	u = battle(1, u, Nappa);
	
	while (u.winloserun > 0)
	{
		if (u.winloserun == 110)
		{
			u.winloserun = 3;
			u = battle(1, u, Nappa);
		}
		else if (u.winloserun == 111)
		{
			u.winloserun = 3;
			u = lastrest(u);
			story6;
			u = battle(1, u, Nappa);
		}
		else if (u.winloserun == 112)
			u = wholestory(u);
	}
	
	u.winloserun = 3;
	
	cout << "Goku: You are a formidable opponent! Too bad I'm already way stronger through my trainings!";
	cinget();
	cout << "Nappa: Ugh... AAAAAAAAAAAAAAA!\n\n\n";
	cinget();
	cout << "The other Saiyans raises his hand and Nappa explodes in a second.\n"
			"???: Such weakling who lose to another weakling is no longer necessary.";
	cinget();
	cout << "Goku: You! How could you kill your own companians! I will destroy you here at this moment!";
	cinget();
	cout << "???: You are still a noob, Goku. You were sent to this planet because you are weak!";
	cinget();
	cout << "???: And didn't Nappa tell you? I am the lord, the prince of all Saiyans who have high abilities since birth";
	cinget();
	cout << "Vegeta: And a low ability worrior such as you will have no chance against me!";
	cinget();
	cout << "Goku: We will have to see. Here I go!!!";
	cinspace();
	
	u = battle(1, u, Vegeta1);
	
	while (u.winloserun > 0)
	{
		if (u.winloserun == 110)
		{
			u.winloserun = 3;
			u = battle(1, u, Vegeta1);
		}
		else if (u.winloserun == 111)
		{
			u.winloserun = 3;
			u = lastrest(u);
			u = battle(1, u, Nappa);
			u.winloserun = 3;
			u = battle(1, u, Vegeta1);
		}
		else if (u.winloserun == 112)
			u = wholestory(u);
	}
	
	u.winloserun = 3;
	
	cout << "Vegeta: Damn...How does a weakling get so strong?!";
	cinget();
	cout << "Goku: Weaklings can change through hard works and efforts!";
	cinget();
	cout << "Vegeta: No, I don't believe you! Now I will show you my real power! Hahahahaha!";
	cinget();
	cout << "Goku: What?!";
	cinget();
	cout << "Vegeta: I am going to transform and obtain unlimited energy! Just watch me!";
	cinget();
	cout << "Vegeta threw his energy ball into the sky and formed a fake moon.";
	cinget();
	cout << "Vegeta: AAAAAAAAAAAAAAARG!";
	cinget();
	cout << "Vegeta is now a giant Gorilla\n\n\n"
			"Vegeta: RAAAAAAAAAAAAR! GOKU! DIE!";
	cinspace();
	
	u = battle(1, u, Vegeta2);
	
	while (u.winloserun > 0)
	{
		if (u.winloserun == 110)
		{
			u.winloserun = 3;
			u = battle(1, u, Vegeta2);
		}
		else if (u.winloserun == 111)
		{
			u.winloserun = 3;
			u = lastrest(u);
			u = battle(1, u, Nappa);
			u.winloserun = 3;
			u = battle(1, u, Vegeta1);
			u.winloserun = 3;
			u = battle(1, u, Vegeta2);
		}
		else if (u.winloserun == 112)
			u = wholestory(u);
	}
	
	u.winloserun = 3;
	cout << "Goku: This is for everyone on the Earth!";
	cinget();
	cout << "Goku: Spirit Bomb!!!!!";
	cinget();
	cout << "Vegeta: Impossible! AAAAAAAAAAAAAA!";
	cinget();
	cout << "The world has finally restored peace, thanks to Goku!\n"
			"Press enter to continue\n";
	cinspace();
	return u;
}