//Header file for my game

const int strsize = 100;			//initialized string size
struct equipstatus					//this structure contains various data for equipment
{
	char ename[strsize];			//name
	short elevel;					//item level
	unsigned int ecombatdamage;		//combat attack item increase
	unsigned int echidamage;		//chi attack item increase
	unsigned int ecombatdef;		//combat def item increase
	unsigned int echidef;			//chi def item increase
};

struct inventory					//this structure contains various data for user inventory
{
	equipstatus icloth;				//cloth in inventory
	equipstatus ihat;				//hat in inventory
	equipstatus iaccesory;			//accesory in inventory
	equipstatus	iweapon;			//weapon in inventory
	int smallhppotion;				//# of small hp potion in inventory
	int largehppotion;				//# of large hp potion in inventory
	int smallchipotion;				//# of small chi potion in inventory
	int largechipotion;				//# of large chi potion in inventory
	int magicalbean;				//# of magical bean in inventory
};

struct status						//this structure initializes player and enemy status
{									//most of those stats are used in battle. Others for equipment, inventory, skill, etc.
	char name[strsize];				//name
	short level;					//level
	unsigned int maxcombatdamage;	//max combat damage
	unsigned int mincombatdamage;	//min combat damage
	unsigned int maxchidamage;		//max chi damage
	unsigned int minchidamage;		//min chi damage
	unsigned int combatdef;
	unsigned int chidef;			//chi and combat def
	int currenthp;
	unsigned int maxhp;
	int currentchi;					//hp and chi. Separated into current value and max value for battle
	unsigned int maxchi;
	equipstatus ecloth;
	equipstatus ehat;
	equipstatus eaccesory;
	equipstatus	eweapon;			//equipped items
	unsigned int skill;
	unsigned int money;				//skill and money
	float experience;				//experience user have(needed for lvling)
	short job;						//later used in story. User can choose jobs.
	short winloserun;				//This is most vital for battle system! Without it, battle cannot funtion properly
	inventory item;					//items in inventory
};

struct total						//this structure is for calculating user's total stats by adding user stat with equip stat
{
	unsigned int tcombatdef;
	unsigned int tchidef;
	unsigned int tmaxatk;
	unsigned int tminatk;
	unsigned int tmaxchi;
	unsigned int tminchi;			//total combat def, chi def, max combat atk, min combat atk, max chi atk, min chi atk
};

//prototype functions with data(stats and battles). Will explain more detailed in actual function.
status battle(int, status, status);
status levelup(status);
unsigned int randomnumber(unsigned int, unsigned int);
total calculatetotal(status);
int damage(unsigned int, int, unsigned int);
status changejob(status);

//separate prototype functions(void + text) Will explain more detailed in actual function.
status wholestory(status);
void display(status);
void skilldisplay(int);
void space();
void wait(int);
void cinget();
void cinspace();
void bossbattle(char[strsize], char[strsize]);
void plainenemybattle();
void ASCIItitle();
void story1();
void story2();
void story3();
void story4();
status menu2(status);
status onthepath(status);
void story5();
status training(status);
status menu3(status);
status pathagain(status);
status lastrest(status);
void story6();
status finalboss(status);
//these are constant data for equipment status
const equipstatus cloth[4]		= 	{								//cloth stats
						{"Nothing", 0, 0, 0, 0, 0},
						{"Kong Fu Suit", 5, 0, 0, 50, 25},
						{"Underworld Suit", 10, 25, 50, 100, 50},
						{"Kai Suit", 15, 50, 50, 150, 150}
					   				};
const equipstatus hat[4]  		= 	{								//hat stats
						{"Nothing", 0, 0, 0, 0, 0},
						{"Kong Fu Hat", 5, 0, 0, 25, 7},
						{"Underworld Hat", 10, 0, 0, 50, 20},
						{"Kai Hat", 15, 100, 100, 200, 100}
					  				};
const equipstatus accesory[3]	=	{								//acc stats
						{"Nothing", 0, 0, 0, 0, 0},
						{"Underworld Neckless", 10, 50, 50, 0, 0},
						{"Kai Neckless", 15, 100, 100, 25, 25}
						 			};
const equipstatus weapon[4]	=		{								//weapon stats
						{"Nothing", 0, 0, 0, 0, 0},
						{"Bronze Sword", 7, 50, 25, 0, 0},
						{"Underworld Sword", 10, 200, 150, 0, 0},
						{"Kai Sword", 15, 400, 300, 0, 0}
									};

const inventory	EI = {cloth[0], hat[0], accesory[0], weapon[0], 0, 0, 0, 0, 0};
																	//constant inventory for enemy, since enemy does not need it. Many variable vital for the user
																	//are not necessarily vital for enemy
const status 	Test 		= 	{"Test", 1, 1000000, 1000000, 1, 1, 1, 1, 1, 1, 1, 1, cloth[0], hat[0], accesory[0], weapon[0], 1, 1, 1, 0, 0, EI},
				Radditz1 	= 	{"Radditz", 5, 500, 350, 100, 50, 100, 10, 3000, 3000, 100, 100, cloth[0], hat[0], accesory[0], weapon[0], 1, 500, 500, 0, 0, EI},
				Radditz2	= 	{"Radditz(Enhanced)", 6, 800, 500, 100, 10, 300, 300, 7000, 7000, 1000, 1000, cloth[0], hat[0], accesory[0], weapon[0], 2, 500, 550, 0, 0, EI},
				Ghoul1		= 	{"Ghoul", 5, 500, 400, 600, 500, 100, 175, 2500, 2500, 5000, 5000, cloth[0], hat[0], accesory[0], weapon[0], 10, 550, 350, 0, 0, EI},
				Ghoul2		=	{"Ghoul(Enhanced)", 7, 600, 450, 700, 550, 125, 200, 3500, 3500, 5000, 5000, cloth[0], hat[0], accesory[0], weapon[0], 10, 700, 450, 0, 0, EI},
		  		Zombie1 	= 	{"Zombie", 5, 650, 450, 150, 100, 150, 100, 3850, 3850, 2500, 2500, cloth[0], hat[0], accesory[0], weapon[0], 2, 500, 400, 0, 0, EI},
		  		Zombie2		=	{"Zombie(Enhanced)", 7, 750, 500, 200, 125, 200, 150, 4500, 4500, 2500, 2500, cloth[0], hat[0], accesory[0], weapon[0], 2, 500, 400, 0, 0, EI},
				SnakeGirl	=	{"Snake Girl", 10, 750, 650, 750, 650, 200, 200, 6000, 6000, 3000, 3000, cloth[0], hat[0], accesory[0], weapon[0], 11, 999, 1000, 0, 0, EI},
				BlueGhost	=	{"Blue Ghost(Spirit)", 10, 600, 500, 800, 700, 175, 200, 5000, 5000, 5000, 5000, cloth[0], hat[0], accesory[0], weapon[0], 10, 1500, 750, 0, 0, EI},
				RedGhost	=	{"Red Ghost(Strength)", 10, 850, 750, 200, 100, 225, 150, 6500, 6500, 1500, 1500, cloth[0], hat[0], accesory[0], weapon[0], 2, 650, 1300, 0, 0, EI},
				Gorilla		=	{"King Kai's Gorilla", 15, 900, 650, 200, 150, 250, 200, 4500, 4500, 1500, 1500, cloth[0], hat[0], accesory[0], weapon[0], 2, 1000, 1150, 0, 0, EI},
				Bee			=	{"King Kai's Bee", 15, 900, 100, 100, 50, 100, 100, 3000, 3000, 2000, 2000, cloth[0], hat[0], accesory[0], weapon[0], 111, 1500, 750, 0, 0, EI},
				WildGorilla	=	{"Wild Gorilla", 20, 1500, 1250, 500, 300, 500, 500, 8000, 8000, 2500, 2500, cloth[0], hat[0], accesory[0], weapon[0], 2, 1000, 2000, 0, 0, EI},
				WildBee		=	{"Wild Bee", 20, 1800, 1000, 800, 500, 300, 300, 7000, 7000, 2000, 2000, cloth[0], hat[0], accesory[0], weapon[0], 111, 1200, 1950, 0, 0, EI},
				SBL			=	{"Monster Trio", 20, 2000, 1500, 1000, 800, 400, 400, 7500, 7500, 3000, 3000, cloth[0], hat[0], accesory[0], weapon[0], 1111, 5000, 30000, 0, 0, EI},
				Nappa		=	{"Nappa", 20, 2000, 1000, 300, 200, 300, 300, 10000, 10000, 1000, 1000, cloth[0], hat[0], accesory[0], weapon[0], 2, 0, 50000, 0, 0, EI},
				Vegeta1		=	{"Vegeta", 25, 2500, 1500, 700, 450, 300, 300, 15000, 15000, 3000, 3000, cloth[0], hat[0], accesory[0], weapon[0], 3, 0, 100000, 0, 0, EI},
				Vegeta2		=	{"Vegeta(Transformed)", 30, 3000, 1500, 0, 0, 350, 350, 20000, 20000, 0, 0, cloth[0], hat[0], accesory[0], weapon[0], 4, 0, 300000, 0, 0, EI};
																	//bunch of enemy status, constant and pre-initialized before game, so they can be used in all prototype functions
																	//many unnecessary data are initialized as "0"(except some status which I set to "0" on purpose
																	//for example, cloth[0], hat[0], EI
																	//Please note that "Test" is only used in test run, not in the actual game