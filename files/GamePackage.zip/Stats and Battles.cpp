//Stats and Battles file for my game

#include <iostream.h>
#include "Header.h"
#include <cstdlib>
#include <ctime>
using namespace std;						//include these to ensure the game runs(see specific description in Main.cpp)

status battle(int b, status g, status e)	//battle imports three variables: enemy status, user status and a number indicating whether the monster is boss or not
											//the number b is important. You will see later
{
	srand(time(0));							//for random number
	short bchoice;
	short lchoice;
	short echoice;
	short schoice;
	short cchoice;
	short ichoice;
	char exitornot;
	short enemyturn;						//those variables are all for choice making and switching turns
	total stat = calculatetotal(g);			//calculate total stat in battle using a prototype function and initialize them as "total" type
	if (b == 0)
		plainenemybattle();
	else if (b == 1)
		bossbattle(g.name, e.name);			//b = 0 means the battle is against plain monster. b = 1 means the battle is against boss monsters. This will make a difference
	while (g.winloserun > 2)				//this battle loop does not end until the variable "winloserun" does not change. It only change when there is a result for the battle(user lose, user win, user run)
	{
		if ((g.currentchi + (0.1 * g.maxchi)) > g.maxchi)
			g.currentchi = g.maxchi;
		else if ((g.currentchi + (0.1 * g.maxchi)) <= g.maxchi)
			g.currentchi = g.currentchi + (0.1 * g.maxchi);
											//this is for restoring chi values at beginning of user's turn
		enemyturn = 0;						//your turn continues as long as enemy's turn is 0
		while (enemyturn == 0 && g.winloserun == 3)
		{									//those two conditions allows your turn to continue
			unsigned int pointerdamage;		//this variable is for the damage later
			cout << g.name << "			Level " << g.level << "\n"
				"HP:	" << g.currenthp << "/" << g.maxhp << "\n"
				"CHI:	" << g.currentchi << "/" << g.maxchi << "\n\n"
				"VERSUS\n\n"
				 <<	e.name << "			Level " << e.level << "\n"
				"HP:	" << e.currenthp << "/" << e.maxhp << "\n"
				"CHI:	" << e.currentchi << "/" << e.maxchi << "\n\n\n\n\n"
				"What do you want to do now? \n"
				"1) Normal Attack					2) See My Status\n"
				"3) Combat Skill/Chi Technique\n"
				"4) Run away(will not work in boss battle =))\n"
				"5) Inventory\n\n\n"		//display user and enemy's general status and shows user his options
				"Enter your choice by inputting the corresponding number and press 'enter':\n";
			cin >> bchoice;
			
			switch(bchoice)					//switch for choice. See general descriptions in text
			{
				case 1:		//normal attack option
					pointerdamage = randomnumber(stat.tmaxatk, stat.tminatk);
							//this randomnumber function generates a random number between a maximum and a minimum value(see how by check the function out)
					e.currenthp = damage(pointerdamage, e.currenthp, e.combatdef);
							//damage received is also calculated by giving the function 3 variables: damage, enemy defence and enemy hp			
					if (e.currenthp <= 0)
					{		//if enemy hp < or = 0, you win
						g.winloserun = 0;
							//winloserun's value changes
						cout << "You win. Press enter to countinue!\n";
						cinspace();
					}
					else
					{		//else moves to enemy's turn
					enemyturn = 1;
							//by using this variable(changed value ends loop for your turn and runs the enemy's turn)
					cout << "\n\n\nNow it's " << e.name << "'s turn.\n"
							"Press enter to countinue.\n";
					cinspace();
					}
											
				break;
			
				case 2:		//see status option
					cout << "Please select the stat you want to see\n\n\n"
							"1) See character stat point and equip\n"
							"2) See character skill\n"
							"3) Go back to battle menu\n";
					cin >> schoice;
					while (schoice != 3)
							//use a while loop for this one
					{	
						if (schoice == 1)
						{
							display(g);
							//this displays Goku's status
							cout << "Please select the stat you want to see\n\n\n"
									"1) See character stat point and equip\n"
									"2) See character skill\n"
									"3) Go back to battle menu\n";
							cin	>> schoice;
						}
						
						else if (schoice == 2)
						{
							skilldisplay(g.skill);
							//this displays Goku's current skill(s)
							cout << "Please select the stat you want to see\n\n\n"
									"1) See character stat point and equip\n"
									"2) See character skill\n"
									"3) Go back to battle menu\n";
							cin	>> schoice;
						}
						
						else if (schoice == 3)
						 	space();
						else
						{
							cout << "That is not a choice!\n"
									"Please select the stat you want to see\n\n\n"
									"1) See character stat point and equip\n"
									"2) See character skill\n"
									"3) Go back to battle menu\n";
							cin	>> schoice;
						}
						
						//else it's exiting or playing game
					}
				break;
				
				case 3:	//skill option
					if (g.skill == 0)
					{	//display this if you have no skill currently
						cout << "You do not have a skill yet! It will be soon available later in the story!\n"
								"Press enter to continue\n";
						cinspace();
					}
					
					else if (g.skill == 11)
					{	//else, display skills user have. When g.skill change, so does user's skills
						cout << "What do you want to use against " << e.name << "?\n\n\n"
								"1) Kamehameha----------------------Consumes 1500 chi\n"
								"2) Makankosappo--------------------Consumes 2500 chi\n"
								"3) Go back to main menu\n";
						cin >> cchoice;
						switch(cchoice)
						{
							case 1: 
								if (g.currentchi - 1500 >= 0)
								{
									g.currentchi = g.currentchi - 1500;
									pointerdamage = randomnumber(stat.tmaxchi, stat.tminchi) + 300;
									e.currenthp = damage(pointerdamage, e.currenthp, e.chidef);
									if (e.currenthp <= 0)
									g.winloserun = 0;
									else
									{
									enemyturn = 1;
									cout << "\n\n\nNow it's " << e.name << "'s turn.\n"
											"Press enter to countinue.\n";
									cinspace();
									}
								}
								
								else
								{
									cout << "You don't have enough chi to preform Kamehameha.\n"
											"Press enter to countinue.\n";
									cinspace();
								}	
							break;
							
							case 2:
								if (g.currentchi - 2500 >= 0)
								{
									g.currentchi = g.currentchi - 2500;
									pointerdamage = (randomnumber(stat.tmaxchi, stat.tminchi) * 1.5) + (randomnumber(stat.tmaxatk, stat.tminatk) * 0.1);
									e.currenthp = damage(pointerdamage, e.currenthp, e.chidef);
									if (e.currenthp <= 0)
										g.winloserun = 0;
									else
									{
									enemyturn = 1;
									cout << "\n\n\nNow it's " << e.name << "'s turn.\n"
											"Press enter to countinue.\n";
									cinspace();
									}
								}
								
								else
								{
									cout << "You don't have enough chi to preform Kamehameha.\n"
											"Press enter to countinue.\n";
									cinspace();
								}	
							break;
								
							case 3:
								space();
							break;
							
							default: 
								cout << "That is not a choice! Please try again.\n"
										"Press enter to continue\n";
								cinspace();
						}
					}
						
					else if (g.skill == 1)
					{
						cout << "What do you want to use against " << e.name << "?\n\n\n"
								"1) Kamehameha----------------------Consumes 1500 chi\n"
								"2) Go back to main menu\n";
						cin >> cchoice;
						switch(cchoice)
						{
							case 1: 
								if (g.currentchi - 1500 >= 0)
								{
									g.currentchi = g.currentchi - 1500;
									pointerdamage = randomnumber(stat.tmaxchi, stat.tminchi) + 300;
									e.currenthp = damage(pointerdamage, e.currenthp, e.chidef);
									if (e.currenthp <= 0)
										g.winloserun = 0;
									else
									{
										enemyturn = 1;
										cout << "\n\n\nNow it's " << e.name << "'s turn.\n"
												"Press enter to countinue.\n";
										cinspace();
									}
								}
									
								else
								{
									cout << "You don't have enough chi to preform Kamehameha.\n"
											"Press enter to countinue.\n";
									cinspace();
								}	
							break;
									
							case 2:
								space();
							break;
								
							default: 
								cout << "That is not a choice! Please try again.\n"
										"Press enter to continue\n";
								cinspace();
						}
					}
					
					else if (g.skill == 110)
					{
						cout << "What do you want to use against " << e.name << "?\n\n\n"
								"1) Kamehameha----------------------Consumes 1500 chi\n"
								"2) Kaoiken-------------------------Consumes 3000 chi\n";
								"3) Go back to main menu\n";
						cin >> cchoice;
						switch(cchoice)
						{
							case 1: 
								if (g.currentchi - 1500 >= 0)
								{
									g.currentchi = g.currentchi - 1500;
									pointerdamage = randomnumber(stat.tmaxchi, stat.tminchi) + 300;
									e.currenthp = damage(pointerdamage, e.currenthp, e.chidef);
									if (e.currenthp <= 0)
										g.winloserun = 0;
									else
									{
										enemyturn = 1;
										cout << "\n\n\nNow it's " << e.name << "'s turn.\n"
												"Press enter to countinue.\n";
										cinspace();
									}
								}
									
								else
								{
									cout << "You don't have enough chi to preform Kamehameha.\n"
											"Press enter to countinue.\n";
									cinspace();
								}	
							break;
									
							case 2:
								if (g.currentchi - 3000 >= 0)
								{
									g.currentchi = g.currentchi - 3000;
									pointerdamage = (randomnumber(stat.tmaxatk, stat.tminatk) * 1.5) + 500;
									e.currenthp = damage(pointerdamage, e.currenthp, e.combatdef);
									if (e.currenthp <= 0)
										g.winloserun = 0;
									else
									{
										enemyturn = 1;
										cout << "\n\n\nNow it's " << e.name << "'s turn.\n"
												"Press enter to countinue.\n";
										cinspace();
									}
								}
									
								else
								{
									cout << "You don't have enough chi to preform Kaoiken.\n"
											"Press enter to countinue.\n";
									cinspace();
								}	
							break;
							
							case 3:
								space();
							break;
							
							default: 
								cout << "That is not a choice! Please try again.\n"
										"Press enter to continue\n";
								cinspace();
						}
					}
						
					else if (g.skill == 101)
					{
						cout << "What do you want to use against " << e.name << "?\n\n\n"
								"1) Kamehameha----------------------Consumes 3000 chi\n"
								"2) Spirit Bomb-------------------------Consumes 5000 chi\n";
								"3) Go back to main menu\n";
						cin >> cchoice;
						switch(cchoice)
						{
							case 1: 
								if (g.currentchi - 3000 >= 0)
								{
									g.currentchi = g.currentchi - 3000;
									pointerdamage = randomnumber(stat.tmaxchi, stat.tminchi) + 300;
									e.currenthp = damage(pointerdamage, e.currenthp, e.chidef);
									if (e.currenthp <= 0)
										g.winloserun = 0;
									else
									{
										enemyturn = 1;
										cout << "\n\n\nNow it's " << e.name << "'s turn.\n"
												"Press enter to countinue.\n";
										cinspace();
									}
								}
									
								else
								{
									cout << "You don't have enough chi to preform Kamehameha.\n"
											"Press enter to countinue.\n";
									cinspace();
								}	
							break;
									
							case 2:
								if (g.currentchi - 5000 >= 0)
								{
									g.currentchi = g.currentchi - 5000;
									pointerdamage = (randomnumber(stat.tmaxchi, stat.tminchi) * 1.5) + 1000;
									e.currenthp = damage(pointerdamage, e.currenthp, e.chidef);
									if (e.currenthp <= 0)
										g.winloserun = 0;
									else
									{
										enemyturn = 1;
										cout << "\n\n\nNow it's " << e.name << "'s turn.\n"
												"Press enter to countinue.\n";
										cinspace();
									}
								}
									
								else
								{
									cout << "You don't have enough chi to preform Spirit Bomb.\n"
											"Press enter to countinue.\n";
									cinspace();
								}	
							break;
							
							case 3:
								space();
							break;
							
							default: 
								cout << "That is not a choice! Please try again.\n"
										"Press enter to continue\n";
								cinspace();
						}
					}
					
				break;

				case 4:
					int chancestorunaway;
					chancestorunaway = rand() % 2 + 1;
					
					if (chancestorunaway == 1)
					{
						if (b == 0)
						{
							if (g.currenthp >= (g.maxhp / 5))
							{
								g.currenthp = g.currenthp / 2;
								g.currentchi = g.currentchi / 2;
							}
							
							else
							{
								g.currenthp = 1;
								g.currentchi = g.currentchi / 2;
							}
						g.winloserun = 2;
						}
										
						else if (b == 1)
						{
							cout << "Running away in a boss battle is not a option!\n"
									"Press Enter to Continue\n";
							cinspace();
						}
					}
					
					else if (chancestorunaway == 2)
					{
						cout << "You have failed to run away! Now it is the enemy's turn\n"
								"Press Enter to Continue\n";
						enemyturn = 1;
						cinspace();
					}
				break;
				case 5:
					cout << "Here are all your items:\n\n\n"
							"Cloth: " << g.item.icloth.ename << "\n"
							"Hat: " << g.item.ihat.ename << "\n"
							"Accesory: " << g.item.iaccesory.ename << "\n"
							"Weapon: " << g.item.iweapon.ename << "\n"
							"Number of small hp potion(s): " << g.item.smallhppotion << "-This stores 20% of your maximum hp\n"
							"Number of large hp potion(s): " << g.item.largehppotion << "-This stores 40% of your maximum hp\n"
							"Number of small chi potion(s): " << g.item.smallchipotion << "-This stores 25% of your maximum chi\n"
							"Number of small hp potion(s): " << g.item.largechipotion << "-This stores 50% of your maximum chi\n"
							"Number of magical bean(s): " << g.item.magicalbean << "-This stores all hp and chi\n"
							"What do you want to use?\n\n\n"
							"1) Small hp potion			2) Large hp potion\n"
							"3) Small chi potion		4) Large chi potion\n"
							"5) Magical bean			6) Go back to main menu\n";
					cin >> ichoice;
					switch(ichoice)
					{
						case 1: 
							if ((g.item.smallhppotion - 1) < 0)
								cout << "You have no small hp potion currently!\n";
							else
							{
								if ((g.currenthp + 0.2 * g.maxhp) >= g.maxhp)
									g.currenthp = g.maxhp;
								else
								{
									g.currenthp = g.currenthp + (0.2 * g.maxhp);
									cout << "Your hp is now restored to " << g.currenthp << "\n"
											"Now it is enemy's turn\n";
								}
								enemyturn = 1;
								g.item.smallhppotion = g.item.smallhppotion - 1;
							}
							cout << "Press enter to continue\n";
							cinspace();
						break;
						
						case 2: 
							if ((g.item.largehppotion - 1) < 0)
								cout << "You have no large hp potion currently!\n";
							else
							{
								if ((g.currenthp + 0.4 * g.maxhp) >= g.maxhp)
									g.currenthp = g.maxhp;
								else
								{
									g.currenthp = g.currenthp + (0.4 * g.maxhp);
									cout << "Your hp is now restored to " << g.currenthp << "\n"
											"Now it is enemy's turn\n";
								}
								enemyturn = 1;
								g.item.largehppotion = g.item.largehppotion - 1;
							}
							cout << "Press enter to continue\n";
							cinspace();
						break;
						
						case 3: 
							if ((g.item.smallchipotion - 1) < 0)
								cout << "You have no small chi potion currently!\n";
							else
							{
								if ((g.currentchi + 0.25 * g.maxchi) >= g.maxchi)
									g.currentchi = g.maxchi;
								else
								{
									g.currentchi = g.currentchi + (0.25 * g.maxchi);
									cout << "Your chi is now restored to " << g.currentchi << "\n"
											"Now it is enemy's turn\n";
								}
								enemyturn = 1;
								g.item.smallchipotion = g.item.smallchipotion - 1;
							}
							cout << "Press enter to continue\n";
							cinspace();
						break;
						
						case 4: 
							if ((g.item.largechipotion - 1) < 0)
								cout << "You have no large chi potion currently!\n";
							else
							{
								if ((g.currentchi + 0.5 * g.maxchi) >= g.maxchi)
									g.currentchi = g.maxchi;
								else
								{
									g.currentchi = g.currentchi + (0.4 * g.maxchi);
									cout << "Your chi is now restored to " << g.currentchi << "\n"
											"Now it is enemy's turn\n";
								}
								enemyturn = 1;
								g.item.largechipotion = g.item.largechipotion - 1;
							}
							cout << "Press enter to continue\n";
							cinspace();
						break;
						
						case 5: 
							if ((g.item.magicalbean - 1) < 0)
								cout << "You have no magical bean currently!\n";
							else
							{
								g.currenthp = g.maxhp;
								g.currentchi = g.maxchi;	
								cout << "You hp and chi are all restored.\n"
										"Hp is now " << g.currenthp << ".\n"
										"Chi is now " << g.currentchi << ".\n";
								enemyturn = 1;
								g.item.magicalbean = g.item.magicalbean - 1;
							}
							cout << "Press enter to continue\n";
							cinspace();
						break;
						
						case 6: 
							space();
						break;
						
						default:
							cout << "That is not a choice\n"
									"Press enter to continue\n";
							cinspace();
					}
				default: 
					cout << "That is not a choice, please pick again.\n"
							"Press Enter to Continue\n";
					cinspace();
			}
		}
		
		unsigned int pointerdamage;
		while (enemyturn == 1 && g.winloserun == 3)
		{
			if ((e.currentchi + (0.1 * e.maxchi)) > e.maxchi)
				e.currentchi = e.maxchi;
			else if ((e.currentchi + (0.1 * e.maxchi)) <= e.maxchi)
				e.currentchi = e.currentchi + (0.1 * e.maxchi); 
		cout << "Please wait until " << e.name << " makes a move!\n\n\n";
		wait(1);
			
			if (e.skill == 1)
			{
				pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
				cout << e.name << " strikes you!\n";
				if ((pointerdamage - 1) <= stat.tcombatdef)
				{
					g.currenthp = g.currenthp - 1;
					cout << "But You only received 1 damage from his weak attack!\n";
				}
				else
				{
					g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
					cout << "You received " << pointerdamage - stat.tcombatdef << " damage.\n";
				}
			}
				
			else if (e.skill == 2)
			{
				echoice = rand() % e.skill + 1;
				switch(echoice)
				{
					case 1:
						pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
						cout << e.name << " strikes you!\n";
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 2:
						if ((e.currentchi - 250) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
						}
						else if (e.currentchi - 250 >= 0)
						{
							e.currentchi = e.currentchi - 250;
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage) + (randomnumber(e.maxchidamage, e.minchidamage) * 2);
							cout << e.name << " uses 250 chi to preform hard punch.\n";
						}
						//---------------------------------------------------separate cases
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
				}
			}
			
			else if (e.skill == 3)
			{
				echoice = rand() % e.skill + 1;
				switch(echoice)
				{
					case 1:
						pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
						cout << e.name << " strikes you!\n";
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 2:
						if ((e.currentchi - 750) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
						}
						else if (e.currentchi - 750 >= 0)
						{
							e.currentchi = e.currentchi - 750;
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage) + (randomnumber(e.maxchidamage, e.minchidamage));
							cout << e.name << " uses 750 chi to preform Saiyan punch.\n";
						}
						//---------------------------------------------------separate cases
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 3:
						if ((e.currentchi - 1000) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
						}
						else if (e.currentchi - 1000 >= 0)
						{
							e.currentchi = e.currentchi - 1000;
							pointerdamage = randomnumber(e.maxchidamage, e.minchidamage) + 3000;
							cout << e.name << " uses 1000 chi to preform Big Bang.\n";
						}
						//---------------------------------------------------separate cases
						if ((pointerdamage - 1) <= stat.tchidef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tchidef);
							cout << "You received " << pointerdamage - stat.tchidef << " damage.";
						}
					break;
				}
			}
			
			else if (e.skill == 4)
			{
				echoice = rand() % e.skill + 1;
				switch(echoice)
				{
					case 1:
						pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
						cout << e.name << " strikes you!\n";
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 2:
						pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage) + 500;
						cout << e.name << " uses 0 chi to preform Saiyan punch.\n";
						//---------------------------------------------------separate cases
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 3:
						pointerdamage = 4000;
						cout << e.name << " uses 0 chi to preform Big Bang.\n";
						//---------------------------------------------------separate cases
						if ((pointerdamage - 1) <= stat.tchidef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tchidef);
							cout << "You received " << pointerdamage - stat.tchidef << " damage.";
						}
					break;
					
					case 4:
						pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage) * 1.5;
						cout << e.name << " uses 0 chi to preform Gorilla Smash.\n";
						//---------------------------------------------------separate cases
						if ((pointerdamage - 1) <= stat.tchidef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
				}
			}
			
			else if (e.skill == 10)
			{
				echoice = rand() % 2 + 1;
				switch(echoice)
				{
					case 1:
						pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
						cout << e.name << " strikes you!\n";
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 2:
						if ((e.currentchi - 500) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
							if ((pointerdamage - 1) <= stat.tcombatdef)
							{
								g.currenthp = g.currenthp - 1;
								cout << "But You only received 1 damage from his weak attack!\n";
							}
							else
							{
								g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
								cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
							}
						}
						else if (e.currentchi - 500 >= 0)
						{
							e.currentchi = e.currentchi - 500;
							pointerdamage = randomnumber(e.maxchidamage, e.minchidamage) + 100;
							cout << e.name << " uses 500 chi to preform haunt.\n";
						//---------------------------------------------------separate cases
							if ((pointerdamage - 1) <= stat.tchidef)
							{
								g.currenthp = g.currenthp - 1;
								cout << "But You only received 1 damage from his weak attack!\n";
							}
							else
							{
								g.currenthp = g.currenthp - (pointerdamage - stat.tchidef);
								cout << "You received " << pointerdamage - stat.tchidef << " damage.";
							}
						}
					break;
				}
			}
			
			else if (e.skill == 11)
			{
				echoice = rand() % 3 + 1;
				switch(echoice)
				{
					case 1:
						pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
						cout << e.name << " strikes you!\n";
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 2:
						if ((e.currentchi - 500) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
							if ((pointerdamage - 1) <= stat.tcombatdef)
							{
								g.currenthp = g.currenthp - 1;
								cout << "But You only received 1 damage from his weak attack!\n";
							}
							else
							{
								g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
								cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
							}
						}
						else if (e.currentchi - 500 >= 0)
						{
							e.currentchi = e.currentchi - 500;
							pointerdamage = randomnumber(e.maxchidamage, e.minchidamage) + 100;
							cout << e.name << " uses 500 chi to preform haunt.\n";
						//---------------------------------------------------separate cases
							if ((pointerdamage - 1) <= stat.tchidef)
							{
								g.currenthp = g.currenthp - 1;
								cout << "But You only received 1 damage from his weak attack!\n";
							}
							else
							{
								g.currenthp = g.currenthp - (pointerdamage - stat.tchidef);
								cout << "You received " << pointerdamage - stat.tchidef << " damage.";
							}
						}
					break;
					
					case 3:
						if ((e.currentchi - 750) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
						}
						else if (e.currentchi - 750 >= 0)
						{
							e.currentchi = e.currentchi - 750;
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage) * 1.2;
							cout << e.name << " uses 750 chi to preform strangle.\n";
						}
						//---------------------------------------------------separate cases
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
				}
			}
			
			else if (e.skill == 111)
			{
				echoice = rand() % 3 + 1;
				switch(echoice)
				{
					case 1:
						pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
						cout << e.name << " strikes you!\n";
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 2:
						if ((e.currentchi - 500) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
							if ((pointerdamage - 1) <= stat.tcombatdef)
							{
								g.currenthp = g.currenthp - 1;
								cout << "But You only received 1 damage from his weak attack!\n";
							}
							else
							{
								g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
								cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
							}
						}
						else if (e.currentchi - 500 >= 0)
						{
							e.currentchi = e.currentchi - 500;
							pointerdamage = randomnumber(e.maxchidamage, e.minchidamage) + 1000;
							cout << e.name << " uses 500 chi to preform scare.\n";
						//---------------------------------------------------separate cases
							if ((pointerdamage - 1) <= stat.tchidef)
							{
								g.currenthp = g.currenthp - 1;
								cout << "But You only received 1 damage from his weak attack!\n";
							}
							else
							{
								g.currenthp = g.currenthp - (pointerdamage - stat.tchidef);
								cout << "You received " << pointerdamage - stat.tchidef << " damage.";
							}
						}
					break;
					
					case 3:
						if ((e.currentchi - 750) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
						}
						else if (e.currentchi - 750 >= 0)
						{
							e.currentchi = e.currentchi - 750;
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage) * 1.25;
							cout << e.name << " uses 750 chi to preform needle attack.\n";
						}
						//---------------------------------------------------separate cases
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 4:
						if ((e.currentchi - 1000) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
						}
						else if (e.currentchi - 1000 >= 0)
						{
							e.currentchi = e.currentchi - 1000;
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage) * 1.2;
							cout << e.name << " uses 1000 chi to preform strangle.\n";
						}
						//---------------------------------------------------separate cases
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;	
				}
			}
			
			else if (e.skill == 1111)
			{
				echoice = rand() % 4 + 1;
				switch(echoice)
				{
					case 1:
						pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
						cout << e.name << " strikes you!\n";
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 2:
						if ((e.currentchi - 1000) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
						}
						else if (e.currentchi - 1000 >= 0)
						{
							e.currentchi = e.currentchi - 1000;
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage) + (randomnumber(e.maxchidamage, e.minchidamage) * 0.5);
							cout << e.name << " uses 1000 chi to preform trio attack.\n";
						}
						//---------------------------------------------------separate cases
						if ((pointerdamage - 1) <= stat.tcombatdef)
						{
							g.currenthp = g.currenthp - 1;
							cout << "But You only received 1 damage from his weak attack!\n";
						}
						else
						{
							g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
							cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
						}
					break;
					
					case 3:
						if ((e.currentchi - 1000) < 0)
						{
							pointerdamage = randomnumber(e.maxcombatdamage, e.mincombatdamage);
							cout << e.name << " strikes you!\n";
							if ((pointerdamage - 1) <= stat.tcombatdef)
							{
								g.currenthp = g.currenthp - 1;
								cout << "But You only received 1 damage from his weak attack!\n";
							}
							else
							{
								g.currenthp = g.currenthp - (pointerdamage - stat.tcombatdef);
								cout << "You received " << pointerdamage - stat.tcombatdef << " damage.";
							}
						}
						else if (e.currentchi - 1000 >= 0)
						{
							e.currentchi = e.currentchi - 1000;
							pointerdamage = randomnumber(e.maxchidamage, e.minchidamage) + 1000;
							cout << e.name << " uses 1000 chi to preform haunt.\n";
						//---------------------------------------------------separate cases
							if ((pointerdamage - 1) <= stat.tchidef)
							{
								g.currenthp = g.currenthp - 1;
								cout << "But You only received 1 damage from his weak attack!\n";
							}
							else
							{
								g.currenthp = g.currenthp - (pointerdamage - stat.tchidef);
								cout << "You received " << pointerdamage - stat.tchidef << " damage.";
							}
						}
					break;
				}
			}
			
			//--------------------------------------------------------------------separate cases
			if (g.currenthp <= 0)
			{
				g.currenthp = 0;
				g.winloserun = 1;
				cout << "Your hp reaches 0! You have lost to " << e.name << "!\n"
						"Press enter to continue.\n";
				cinspace();
			}
			
			if (g.winloserun > 2)
			{
				cout << "Now it is your turn!\n\n";
				cout << "Press enter to countinue\n";
				cinspace();
			}
			enemyturn = 0;
		}
	}

	if (g.winloserun == 0)
	{
		
		g.money = g.money + e.money;
		g.experience = g.experience + e.experience;
		cout << "You have defeated " << e.name << ". You get " << e.money << " Z coins and " << e.experience << " experience\n\n\n"
				"Press enter to continue\n";
		cinspace();
		float stackexperience[50];
		stackexperience[5] = 0;
		stackexperience[6] = 50;
		for (int i = 7; i < 50; i++)
			stackexperience[i] = (stackexperience[i-1] * 2);
		while (g.experience >= (500 + stackexperience[g.level]))
		{
			g = levelup(g);
			g.experience = g.experience - (500 + stackexperience[g.level - 1]);
		}
	}
	
	else if (g.winloserun == 1)
	{
		if (b == 0)
		{
			g.money = g.money/2;
			g.experience = g.experience/2;
			g.winloserun = 10;
			cout << "You lost " << g.experience << " experience and " << g.money << " Z Coins.\n"
					"You have returned to the nearest savepoint.\n"
					"Press Enter to Continue";
			cinspace();
		}
		
		else if (b == 1)
		{
			while (g.winloserun < 110)
			{
				cout << "You have lost in a boss battle!\n"
						"What do you want to do now?\n"
						"1) Challenge " << e.name << " again with full hp and chi\n2) Respawn at the nearest savepoint(with half hp/chi)\n"
						"3) Start at the beginning of the story	again\n4) Exit the game\n\n\n"
						"Enter your choice: ";
				cin >> lchoice;
				switch(lchoice)
				{
					case 1:
						g.currenthp = g.maxhp;
						g.currentchi = g.maxchi;
						g.winloserun = 110;
					break;
					
					case 2:
						g.currenthp = g.maxhp / 2;
						g.currentchi = g.maxchi / 2;
						g.winloserun = 111;
					break;

					case 3:
						g.winloserun = 112;
					break;
					
					case 4:
						cout << "Are you sure?<y/n>\n";
						cin >> exitornot;
						if (exitornot == 'y' || exitornot == 'Y')
							exit(0);
						else if (exitornot == 'n' || exitornot == 'N')
							space();
					break;
					
					default:
						cout << "That is not a choice! Press enter to countinue.\n";
						cinspace();
				}
			}
		}
	}
	
	else if (g.winloserun == 2)
	{
		if (g.currenthp >= (g.maxhp / 5))
		{
			g.currenthp = g.currenthp / 2;
			g.currentchi = g.currentchi / 2;
		}
							
		else
		{
			g.currenthp = 1;
			g.currentchi = g.currentchi / 2;
		}
		cout << "You ran away in disgrace =(\n"
				"Current hp drops to " << g.currenthp << "\n"
				"Current chi drops to " << g.currentchi << "\n"
				"Press Enter to Continue\n";
		cinspace();
	}
	
	return g;
}

status levelup(status n)
{
	if (n.job == 0)
	{
	n.level = n.level + 1;
	n.mincombatdamage = n.mincombatdamage + 25;
	n.maxcombatdamage = n.maxcombatdamage + 50;
	n.minchidamage = n.minchidamage + 25;
	n.maxchidamage = n.maxchidamage + 50;
	n.combatdef = n.combatdef + 15;
	n.chidef = n.chidef + 15;
	n.maxhp = n.maxhp + 200;
	n.currenthp = n.maxhp;
	n.maxchi = n.maxchi + 200;
	n.currentchi = n.maxchi;
	}
	
	else if (n.job == 1)
	{
	n.level = n.level + 1;
	n.mincombatdamage = n.mincombatdamage + 100;
	n.maxcombatdamage = n.maxcombatdamage + 150;
	n.minchidamage = n.minchidamage + 25;
	n.maxchidamage = n.maxchidamage + 50;
	n.combatdef = n.combatdef + 50;
	n.chidef = n.chidef + 15;
	n.maxhp = n.maxhp + 400;
	n.currenthp = n.maxhp;
	n.maxchi = n.maxchi + 200;
	n.currentchi = n.maxchi;
	}
	
	else if (n.job == 2)
	{
	n.level = n.level + 1;
	n.mincombatdamage = n.mincombatdamage + 20;
	n.maxcombatdamage = n.maxcombatdamage + 50;
	n.minchidamage = n.minchidamage + 125;
	n.maxchidamage = n.maxchidamage + 175;
	n.combatdef = n.combatdef + 10;
	n.chidef = n.chidef + 65;
	n.maxhp = n.maxhp + 100;
	n.currenthp = n.maxhp;
	n.maxchi = n.maxchi + 500;
	n.currentchi = n.maxchi;
	}
	cout << "Congradulation, " << n.name << " have leveled up to lv " << n.level << ".\n\n\n"
			"Minimum combat attack is now " << n.mincombatdamage << ".\n"
			"Maximum combat attack is now " << n.maxcombatdamage << ".\n"
			"Minimum chi attack is now " << n.minchidamage << ".\n"
			"Minimum chi attack is now " << n.maxchidamage << ".\n"
			"Combat defence attack is now " << n.combatdef << ".\n"
			"Chi defence attack is now " << n.chidef << ".\n"
			"Maximum HP is now " << n.maxhp << ".\n"
			"Maximum CHI is now " << n.maxchi << ".\n"
			"Current HP and CHI are fully recovered.\n"
			"Press enter to continue\n";
	cinspace();
									
	return n;
}

unsigned int randomnumber(unsigned int maximum, unsigned int minimum)
{
	srand(time(0));
	int initialdamage;
	initialdamage = rand() % maximum + 1;
	while (initialdamage < minimum)
		initialdamage = rand() % maximum + 1;
	return initialdamage;
}

total calculatetotal(status gtotal)
{
	total calc;
	calc.tcombatdef = gtotal.combatdef+gtotal.ecloth.ecombatdef+gtotal.ehat.ecombatdef+gtotal.eaccesory.ecombatdef+gtotal.eweapon.ecombatdef;
	calc.tchidef = gtotal.chidef+gtotal.ecloth.echidef+gtotal.ehat.echidef+gtotal.eaccesory.echidef+gtotal.eweapon.echidef;
	calc.tmaxatk = gtotal.maxcombatdamage+gtotal.ecloth.ecombatdamage+gtotal.ehat.ecombatdamage+gtotal.eaccesory.ecombatdamage+gtotal.eweapon.ecombatdamage;
	calc.tminatk = gtotal.mincombatdamage+gtotal.ecloth.ecombatdamage+gtotal.ehat.ecombatdamage+gtotal.eaccesory.ecombatdamage+gtotal.eweapon.ecombatdamage;
	calc.tmaxchi = gtotal.maxchidamage+gtotal.ecloth.echidamage+gtotal.ehat.echidamage+gtotal.eaccesory.echidamage+gtotal.eweapon.echidamage;
	calc.tminchi = gtotal.minchidamage+gtotal.ecloth.echidamage+gtotal.ehat.echidamage+gtotal.eaccesory.echidamage+gtotal.eweapon.echidamage;
	return calc;
}

int damage(unsigned int dmg, int remainhp, unsigned int def)
{
	if ((dmg - 1) <= def)
	{
		remainhp = remainhp - 1;
		cout << "The enemy only received 1 damage. Your attack is too weak!\n";
	}
	else
	{
		remainhp = remainhp - (dmg - def);
		cout << "The enemy received " << dmg - def << " damage.\n";
	}
	
	return remainhp;
}

status changejob(status n)
{
	if (n.job == 1)
	{
	n.level = 5;
	n.mincombatdamage = n.mincombatdamage + 500;
	n.maxcombatdamage = n.maxcombatdamage + 500;
	n.minchidamage = n.minchidamage + 100;
	n.maxchidamage = n.maxchidamage + 50;
	n.combatdef = n.combatdef + 300;
	n.chidef = n.chidef + 150;
	n.maxhp = n.maxhp + 2000;
	n.currenthp = n.maxhp;
	n.maxchi = n.maxchi + 500;
	n.currentchi = n.maxchi;
	n.skill = 110;
	}
	
	else if (n.job == 2)
	{
	n.level = 5;
	n.mincombatdamage = n.mincombatdamage + 200;
	n.maxcombatdamage = n.maxcombatdamage + 100;
	n.minchidamage = n.minchidamage + 750;
	n.maxchidamage = n.maxchidamage + 500;
	n.combatdef = n.combatdef + 50;
	n.chidef = n.chidef + 350;
	n.maxhp = n.maxhp + 500;
	n.currenthp = n.maxhp;
	n.maxchi = n.maxchi + 3000;
	n.currentchi = n.maxchi;
	n.skill = 101;
	}
	cout << "Please note that Goku has returned to level 5, but the ability is not decreased\n\n\n"
			"Minimum combat attack is now " << n.mincombatdamage << ".\n"
			"Maximum combat attack is now " << n.maxcombatdamage << ".\n"
			"Minimum chi attack is now " << n.minchidamage << ".\n"
			"Minimum chi attack is now " << n.maxchidamage << ".\n"
			"Combat defence attack is now " << n.combatdef << ".\n"
			"Chi defence attack is now " << n.chidef << ".\n"
			"Maximum HP is now " << n.maxhp << ".\n"
			"Maximum CHI is now " << n.maxchi << ".\n"
			"Current HP and CHI are fully recovered.\n"
			"Press enter to continue\n";
	cinspace();
									
	return n;
}