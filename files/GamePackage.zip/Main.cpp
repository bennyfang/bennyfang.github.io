//Main file for my game

#include <iostream.h>			//Most vital to include
#include "Header.h"				//Include all prototype functions and constant values, initialized
#include <cstdlib>				//For random numbers
#include <ctime>				//For random numbers and waits
using namespace std;			//Most vital to include

void main()						//Main has no return

{
	inventory GI = EI;			//initialize another inventory variable for user
 	status 	YCheat 	= {"Cheater Noob", 5, 10000, 10000, 10000, 10000, 10000, 10000, 50000, 50000, 30000, 30000, cloth[0], hat[0], accesory[0], weapon[0], 0, 0, 0, 0, 3, GI},
 		 	NCheat 	= {"Goku", 5, 500, 400, 500, 400, 100, 100, 5000, 5000, 3000, 3000, cloth[1], hat[1], accesory[0], weapon[0], 0, 0, 0, 0, 3, GI};
 		 						//initialize two sets of user data, one for cheat mode and one for normal mode
 	ASCIItitle();				//void function
	int choice;					//choice for switch
	char start;					//this variable is vital to end the loop
	char cheat1 = 'B';
	char cheat2 = 'b';			//two variables for cheats
	char activatecheat;			//variable for activating cheats
	while (start != 's')		//let loop run until start = s
	{	
		space();				//this is a prototype function that creates space and blanks, which moves the text
		cout << "What do you want to do?\n\n"
		        "1)Start			2)Help\n"
		        "3)Background		4)Exit\n\n\n"
		        "Enter your choice by inputting the corresponding number  and press 'enter':\n";
		        				//texts
		cin >> choice;
		switch(choice)			//switch for choice. See choice description in the texts.
		{
		case 1: 
			start = 's';
			space();
			NCheat = wholestory(NCheat);
								//this is non-cheat mode
		break;
			
		case 2:
			cout << "The instruction is simple. To avoid error, please follow the instruction when inputting.\n"
					"As story proceeds, you will receive more instruction and information abouy gameplay.\n"
					"If you finish reading a message and want to skip to the next one, press enter to do so.(may have to press twice)\n"
					"Right now, just try to play the game and enjoy it =)\n\n\n\n\n"
					"Press any key to continue\n";
			cinspace();			//this is a prototype function that moves the text only after user press a key and enter
		break;
		
		case 3:
			cout << "You are controlling Goku from the original Dragon Ball (DB) , who is now grown up.\n"
					"Just as the actual Dragon Ball Z, you will fight many enemies from Raddiz to Frieza.\n"
					"To find out more about background, just simply play the game!\n\n\n\n\n"
					"Press any key to continue\n";
			cinspace();
		break;
		
		case 4:
			exit(0);				//end game when this case is chosen
		break;
		
		case 5:						//this is a secret case. It allows user to activate cheat mode
			cin >> activatecheat;	//if user enter correct letter, enter cheat mode
			if (activatecheat == cheat1 || activatecheat == cheat2)
			{
				cout << "\aCheat activated!!!!!\n\n\n\n\n"
						"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
						"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
						"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
						"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
						"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
						"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
						"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
						"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB\n\n\n\n\n\n\n\n\n\n";
				wait(5);
				start = 's';
				space();
				YCheat = wholestory(YCheat);
									//this is cheat mode. Note that using this mode will be called a "NOOB"!
			}	
			
			else					//else, "not a choice" will show
			{
				cout << "That is not a choice, please select again.\n\n\n\n\n"
						"Press any key to continue\n";
				cinspace();
			}
		break;
		
		default: 					//default is "not a choice"
			cout << "That is not a choice, please select again.\n\n\n\n\n"
					"Press any key to continue\n";
			cinspace();	
		}
	}								//switch ends here
	
	if (activatecheat == 'b' || activatecheat == 'B')
	{
		cout << "Too bad. Even if you pass this, you are still a noob!\n\n\n\n\n"
				"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
				"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
				"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
				"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
				"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
				"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
				"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
				"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB"
				"NOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOBNOOB\n\n\n\n\n\n\n\n\n\n";
		wait(5);
		cout << "You don't deserve to play my game. GO AWAY!!!\n\n\n\n\n\n\n\n\n\n"
				"You have been disconnected from this game due to your crappy internet connections. I'm not sorry for any inconvenience.\n";
		exit(0);
	}								//two ways to end game
									//if finish cheat mode, I will taunt you at the end and end the game in a error way!
	
	else
	{
		cout << "Thank you for playing!\n"
				"Press anykey to exit!\n";
		cinget();
		exit(0);
	}								//else, I will say nicely to you "Thank you for playing"!
}									//Main ends. Please see prototype function files for details for the game. This is only an outline.